##### figure 1#####
### DEP (proteomics)
library(readr)
library(dplyr)
library(limma)
library(impute)
library(readxl)
library(tidyverse)
library(ggplot2)
library(ggVolcano)

data <- read.table("//", header=TRUE, sep="\t", 
                   fill=TRUE, quote="", comment.char="")
str(data)
head(data)

lines <- data$Description
gene_names <- sub(".*GN=([A-Z0-9]+).*", "\\1", lines)
print(gene_names)

data_clean <- data %>% filter(rowMeans(is.na(.)) < 0.5)
data_clean <- as.data.frame(data_clean)
data_clean <- as.matrix(data_clean)
sum(is.na(data_clean))   
sum(is.nan(as.matrix(data_clean)))  
sum(is.infinite(as.matrix(data_clean)))  

data_clean <- as.data.frame(lapply(data_clean, unlist))
data_imputed <- impute.knn(as.matrix(data_clean))$data

data_norm <- log2(data_clean + 1)
rownames(data_clean) <- data_clean$Gene  
data_clean <- data_clean[, -1]
str(data_clean)
data_matrix <- as.matrix(data_clean)
mode(data_matrix) <- "numeric"  

group <- factor(rep(c("ICH", "CON"), times = c(40, 20)))  
design <- model.matrix(~0 + group) 
colnames(design) <- levels(group)  

fit <- lmFit(data_matrix, design)
contrast.matrix <- makeContrasts(ICH-CON, levels=design)
fit2 <- contrasts.fit(fit, contrast.matrix)
fit2 <- eBayes(fit2)

diff_results <- topTable(fit2, adjust="fdr", number=Inf)
diff_results <- data.frame(Gene=gene_names, diff_results)
write.table(diff_results, "Differential_Proteins.txt", 
            sep="\t", row.names=FALSE, quote=FALSE)
head(diff_results)  

diff_results_filtered <- diff_results %>% filter(abs(logFC) > 0.585 & adj.P.Val < 0.05)
write.csv(diff_results_filtered, "diff_results.csv")  

data <- read.table("Differential_Proteins.txt", header=TRUE, sep="\t", 
                   fill=TRUE, quote="", comment.char="")
str(data)

data<- add_regulate(data,log2FC_name ="logFC",
                    fdr_name="adj.P.Val",log2FC =0.585, fdr =0.05)

p_volcano<-ggvolcano(data, x="log2FoldChange", y="padj",
              label="Gene", legend_position='DR',label_number=20, output=FALSE)
p_volcano

ggsave("p_volcano.png",p1, dpi =300, height =5, width =6)
ggsave("p_volcano.pdf",p1, dpi =300, height =5, width =6)


### GO,KEGG,REACTOME (protomeics)
library(org.Hs.eg.db)
library(clusterProfiler)
library(ReactomePA)
library(reactome.db)
library(dplyr)
library(ggplot2)
library(readr)
library(gground)
library(ggprism)
library(tidyverse)

data_protein<- read.csv("diff_results.csv")
protein <- data_protein$Gene
protein_df <- bitr(protein, fromType = "SYMBOL", 
                   toType = "ENTREZID", OrgDb = org.Hs.eg.db)
protein_entrez <- protein_df$ENTREZID

ego_protein <- enrichGO(gene = protein_entrez, OrgDb = org.Hs.eg.db,
                        ont = "ALL", pAdjustMethod = "BH",
                        pvalueCutoff = 0.05,qvalueCutoff = 0.2, readable = TRUE)
kegg_protein <- enrichKEGG(gene = protein_entrez, organism = "hsa", pvalueCutoff = 0.05)
reactome_protein <- enrichPathway(gene = protein_entrez, organism = "human",
                                  pvalueCutoff = 0.05, readable = TRUE)
write.csv(ego_protein, "ego_protein.csv", row.names = FALSE)
write.csv(kegg_protein, "kegg_protein.csv", row.names = FALSE)
write.csv(reactome_protein, "reactome_protein.csv", row.names = FALSE)

ego_df <- as.data.frame(ego_protein@result)
reactome_df <- as.data.frame(reactome_protein@result)

use_pathway <- group_by(ego_df, ONTOLOGY) %>%
  top_n(5, wt = -p.adjust) %>%
  group_by(p.adjust) %>%
  top_n(1, wt = Count) %>%
  rbind(
    top_n(reactome_df, 5, Count) %>%
      group_by(p.adjust) %>%
      top_n(1, wt = Count) %>%
      mutate(ONTOLOGY = 'reactome')
  ) %>%
  ungroup() %>%
  mutate(ONTOLOGY = factor(ONTOLOGY, 
                           levels = rev(c('BP', 'CC', 'MF', 'reactome')))) %>%
  dplyr::arrange(ONTOLOGY, p.adjust) %>%
  mutate(Description = factor(Description, levels = Description)) %>%
  tibble::rowid_to_column('index')

width <- 1
xaxis_max <- max(use_pathway$Count) + 1
rect.data <- group_by(use_pathway, ONTOLOGY) %>%
  reframe(n = n()) %>%
  ungroup() %>%
  mutate(
    xmin = -3 * width,
    xmax = -2 * width,
    ymax = cumsum(n),
    ymin = lag(ymax, default = 0) + 0.6,
    ymax = ymax + 0.4
  )

pal <- c('#7bc4e2', '#acd372', '#fbb05b','#ed6ca4')
pdf('pathway_protein.pdf', width = 15, height = 12)
use_pathway %>%
  ggplot(aes(Count, y = index, fill = ONTOLOGY)) +
  geom_round_col(
    aes(y = Description), width = 0.6, alpha = 0.8
  ) +
  geom_text(
    aes(x = 0.05, label = Description),
    hjust = 0, size = 5
  ) +
  geom_text(
    aes(x = 0.1, label = geneID, colour = ONTOLOGY), 
    hjust = 0, vjust = 2.6, size = 3.5, fontface = 'italic', 
    show.legend = FALSE
  ) +
  geom_point(
    aes(x = -width, size = Count),
    shape = 21
  ) +
  geom_text(
    aes(x = -width, label = Count)
  ) +
  scale_size_continuous(name = 'Count', range = c(5, 16)) +
  geom_round_rect(
    aes(xmin = xmin, xmax = xmax, ymin = ymin, ymax = ymax,
        fill = ONTOLOGY),
    data = rect.data,
    radius = unit(2, 'mm'),
    inherit.aes = FALSE
  ) +
  geom_text(
    aes(x = (xmin + xmax) / 2, y = (ymin + ymax) / 2, label = ONTOLOGY),
    data = rect.data,
    inherit.aes = FALSE
  ) +
  geom_segment(
    aes(x = 0, y = 0, xend = xaxis_max, yend = 0),
    data = data.frame(xaxis_max = xaxis_max),
    linewidth = 1.5,
    inherit.aes = FALSE
  ) +
  labs(y = NULL) +
  scale_fill_manual(name = 'Category', values = pal) +
  scale_colour_manual(values = pal) +
  scale_x_continuous(
    breaks = seq(0, xaxis_max, 10), 
    expand = expansion(c(0, 0))
  ) +
  theme_prism() +
  theme(
    axis.text.y = element_blank(),
    axis.line = element_blank(),
    axis.ticks.y = element_blank(),
    legend.title = element_text()
  )
dev.off()

### DEG(bulk RNA)
library(data.table)   
library(GEOquery)     
library(limma)       
library(umap)        
library(dplyr)       
library(tidyr)      
library(stringr)     
library(readr)

### GSE24265
gset <- getGEO("GSE24265", GSEMatrix = TRUE, getGPL = FALSE)
length(gset) 
idx <- 1      
gset <- gset[[idx]]
exp <- exprs(gset)
exp = exp %>% as.data.frame()

meta <- gset@phenoData@data
head(rownames(exp))
gpl <- getGEO("GPL570")
probe_anno <- Table(gpl)
colnames(probe_anno)

transid <- function(probe_anno, exp, method = median) {
  probe_anno$ID <- as.character(probe_anno$ID)
  exp$ID <- as.character(exp$ID)
  exp %>%
    dplyr::inner_join(probe_anno, by = "ID") %>%       
    dplyr::select(-ID) %>%                           
    dplyr::select(symbol, everything()) %>%          
    dplyr::mutate(ref = apply(across(where(is.numeric)), 1, method)) %>%  
    dplyr::arrange(desc(ref)) %>%                    
    dplyr::select(-ref) %>%                        
    dplyr::distinct(symbol, .keep_all = TRUE)        
}

length(grep('///', probe_anno$`Gene Symbol`))
probe_anno$symbol <- sub("([^/]+).*", "\\1", probe_anno$`Gene Symbol`)
probe_anno <- probe_anno[-grep('///', probe_anno$`Gene Symbol`), ]  
exp$ID <- rownames(exp)
probe_anno$symbol <- probe_anno$`Gene Symbol`
probe_anno <- probe_anno %>% dplyr::filter(symbol != "---" & !is.na(symbol) & symbol != "")

expression <- transid(probe_anno, exp, method = median)
table(is.null(expression$symbol))
table(duplicated(expression$symbol))

rownames(expression) <- expression$symbol
colnames(expression)
expression <- expression[, 2:12]

colnames(expression) <- paste0('GSE24265_', colnames(expression), '_', 
                               c('Disease','Control','Control','Disease',
                                 'Control','Control','Disease','Control',
                                 'Disease','Control','Control'))
colnames(expression)


qx = as.numeric(quantile(expression, c(0, 0.25, 0.5, 0.75, 0.99, 1.0), na.rm = T))
LogC = ((qx[5] > 100) || ((qx[6] - qx[1]) > 50 && qx[2] > 0))

if (LogC) {
  expression[expression < 0] = 0
  expression = log2(expression + 1)
}

data = normalizeBetweenArrays(expression)
write.csv(data, 'GSE24265_normalized.csv')

###  GSE125512
data <- read_tsv("/GSE125512_norm_counts_TPM_GRCh38.p13_NCBI.tsv")
anno <- read_tsv("~/Human.GRCh38.p13.annot.tsv")

table(data$GeneID == anno$GeneID)
data$symbol <- anno$Symbol
data <- data.frame(data[!duplicated(data$symbol),]) 
rownames(data) <- data$symbol
data <- data.frame(data[,2:23])
colnames(data)

colnames(data) <- paste0('GSE125512_', colnames(data), '_', 
                         c(rep(c('Disease','Control'),11)))
colnames(data)

qx = as.numeric(quantile(data, c(0, 0.25, 0.5, 0.75, 0.99, 1.0), na.rm = T))
LogC = ((qx[5] > 100) || ((qx[6] - qx[1]) > 50 && qx[2] > 0))
LogC 
if (LogC) {
  data[data < 0] = 0
  data = log2(data + 1)
}
data = normalizeBetweenArrays(data)
write.csv(data, 'GSE125512_normalized.csv')

### protein
test_data <- read.csv("Test_data.csv",header = T,row.names = 1)

colnames(test_data) <- paste0('Test_', colnames(test_data), '_', 
                              c(rep('Disease',40),rep('Control',20)))
colnames(test_data)

qx = as.numeric(quantile(test_data, c(0, 0.25, 0.5, 0.75, 0.99, 1.0), na.rm = T))
LogC = ((qx[5] > 100) || ((qx[6] - qx[1]) > 50 && qx[2] > 0))

if (LogC) {
  expression[expression < 0] = 0
  expression = log2(expression + 1)
}

data = normalizeBetweenArrays(test_data)

selected_gene <- read.csv("diff_results.csv")
table(selected_gene$Gene %in% rownames(test_data))
data <- data[selected_gene$Gene,]
write.csv(data, 'test_normalized.csv')

### merge
library(limma)
library(sva)
library(collapse)
library(harmony)
library(data.table)
library(harmony)

input_files <- c('GSE24265_normalized.csv', 'GSE125512_normalized.csv')

get_common_genes <- function(files) {
  gene_sets <- list()
  for (i in seq_along(files)) {
    data <- data.table::fread(files[i], header = TRUE)
    gene_sets[[i]] <- unique(data[[1]])  
  }
  Reduce(intersect, gene_sets)
}
common_genes <- get_common_genes(input_files)

merged_data <- NULL
batch_labels <- c()

for (i in seq_along(input_files)) {
  expr_data <- data.table::fread(input_files[i], header = TRUE)
  gene_names <- expr_data[[1]]
  expr_matrix <- as.matrix(expr_data[, -1])
  rownames(expr_matrix) <- gene_names
  expr_common <- expr_matrix[rownames(expr_matrix) %in% common_genes, ]
  dedup_expr <- collapse::fmean(expr_common, g = rownames(expr_common))
  if (is.null(merged_data)) {
    merged_data <- dedup_expr
  } else {
    merged_data <- cbind(merged_data, dedup_expr)
  }
  batch_labels <- c(batch_labels, rep(i, ncol(dedup_expr)))
}

write.table(merged_data, file = "merged_train_data.txt", 
            sep = "\t", quote = FALSE, row.names = TRUE)

harmony_obj <- HarmonyMatrix(
  data_mat = t(merged_data),   
  meta_data = data.frame(batch = batch_labels),
  vars_use = 'batch',
  do_pca = TRUE
)

corrected_data <- t(harmony_obj)

write.table(corrected_data, file = "merged_normalized_train_data.txt",
            sep = "\t", quote = FALSE, row.names = TRUE)

# data_adjust
library(ggplot2)
library(reshape2)

ZSZ_boxplot <- function(data_file, 
                        plot_title = "gene expression",
                        project_pattern = "(.+)\\_(.+)\\_(.+)", 
                        sample_pattern = "(.+)\\_(.+)\\_(.+)", 
                        color_palette = "Set3",
                        output_file = NULL) {
  
  if (!file.exists(data_file)) {
    stop(paste("none:", data_file))
  }
  
  tryCatch({
    raw_data <- read.table(data_file, header = TRUE, sep = "\t", check.names = FALSE, row.names = 1)
  }, error = function(e) {
    stop(paste("false:", e$message))
  })
  
  transposed_data <- t(raw_data)
  Project = gsub(project_pattern, "\\1", rownames(transposed_data))
  Sample = gsub(sample_pattern, "\\2", rownames(transposed_data))
  plot_data <- cbind(as.data.frame(transposed_data), Sample, Project)
  long_data <- reshape2::melt(plot_data, id.vars = c("Project", "Sample"))
  colnames(long_data) = c("Project", "Sample", "Gene", "Expression")
  p <- ggplot(long_data, aes(x = Sample, y = Expression, fill = Project)) +
    geom_boxplot(alpha = 0.8, outlier.shape = NA) +
    stat_summary(
      fun = median, 
      geom = "point", 
      color = "black", 
      size = 1.5
    ) +
    labs(
      title = plot_title,
      x = "Sample",
      y = "Expression",
      fill = "GSE_dataset"
    ) +
    theme_minimal() +
    theme(
      axis.text.x = element_text(angle = 40, hjust = 1, size = 8),
      plot.title = element_text(hjust = 0.5, size = 14, face = "bold"),
      legend.position = "bottom"
    ) +
    scale_fill_brewer(palette = color_palette)
  if (!is.null(output_file)) {
    tryCatch({
      ggsave(output_file, plot = p, width = 10, height = 6, device = "pdf")
      message(paste("save:", output_file))
    }, error = function(e) {
      warning(paste("NA:", e$message))
    })
  }
  print(p)
  return(p)
}

ZSZ_boxplot(
  data_file = "merged_train_data.txt",
  plot_title = "Expression_before_batch_correction",
  output_file = "1_Before_batch_correction.pdf"
)

ZSZ_boxplot(
  data_file = "merged_normalized_train_data.txt",
  plot_title = "Expression_after_batch_correction",
  color_palette = "Paired",       
  output_file = "2_After_batch_correction.pdf"
)

# PCA
ZSZ_pca <- function(expression_file, 
                    output_pdf, 
                    plot_title = "Principal Component Analysis",
                    group_pattern = "(.+)\\_(.+)\\_(.+)", 
                    point_size = 2, 
                    point_alpha = 0.8) {
  if (!file.exists(expression_file)) {
    stop(paste("false:", expression_file))
  }
  expr_data <- read.table(expression_file, header = TRUE, sep = "\t", 
                          check.names = FALSE, row.names = 1)
  transposed_data <- t(expr_data)
  tryCatch({
    groups <- gsub(group_pattern, "\\1", rownames(transposed_data))
    if (length(unique(groups)) < 2) {
      warning("cannot")
    }
  }, error = function(e) {
    stop(paste("false:", e$message))
  })
  pca_result <- prcomp(transposed_data, scale. = TRUE, center = TRUE)
  pca_scores <- as.data.frame(pca_result$x)
  variance_explained <- summary(pca_result)$importance[2, 1:2] * 100
  plot_data <- data.frame(
    PC1 = pca_scores[, 1],
    PC2 = pca_scores[, 2],
    Group = factor(groups)
  )
  p <- ggplot(plot_data, aes(x = PC1, y = PC2, color = Group)) +
    geom_point(size = point_size, alpha = point_alpha) +
    stat_ellipse(level = 0.95, linewidth = 0.8, show.legend = FALSE) + 
    labs(
      title = plot_title,
      x = paste0("PC1 (", round(variance_explained[1], 1), "% Variance)"),
      y = paste0("PC2 (", round(variance_explained[2], 1), "% Variance)"),
      color = "GSE_dataset"
    ) +
    theme_bw() +
    theme(
      plot.title = element_text(hjust = 0.5, face = "bold"),
      legend.position = "bottom",
      panel.grid.major = element_line(color = "grey90"),
      panel.grid.minor = element_blank(),
      panel.border = element_rect(fill = NA, color = "grey50", linewidth = 0.5)
    ) +
    guides(color = guide_legend(nrow = 1)) +
    scale_color_viridis_d(option = "plasma")  
  tryCatch({
    ggsave(output_pdf, plot = p, width = 7, height = 5, device = "pdf")
    message(paste("save:", output_pdf))
  }, error = function(e) {
    warning(paste("false:", e$message))
  })
  print(p)
}

ZSZ_pca(
  expression_file = "merged_train_data.txt",
  output_pdf = "3_raw_data_pca.pdf",
  plot_title = "PCA analysis before batch correction"
)
ZSZ_pca(
  expression_file = "merged_normalized_train_data.txt",
  output_pdf = "4_normalized_data_pca.pdf",
  plot_title = "PCA analysis after batch correction"
)

### gene expression
library(limma)    
library(dplyr)    
library(pheatmap)  
library(ggplot2)  
library(ggrepel)

logFCfilter = 0.585         
adj.P.Val.Filter = 0.05    
inputFile =  read.table('merged_normalized_train_data.txt', header=T, sep="\t", 
                        check.names=F, row.names=1) 

rt = inputFile
rt = as.matrix(rt)
dimnames = list(rownames(rt), colnames(rt))
data = matrix(as.numeric(as.matrix(rt)), nrow=nrow(rt), dimnames=dimnames)
data = avereps(data)        

colnames(data)
Type = gsub("(.+)\\_(.+)\\_(.+)", "\\3", colnames(data))  
table(Type)
data = data[, order(Type)]  

Project = gsub("(.+)\\_(.+)\\_(.+)", "\\1", colnames(data))  
table(Project)
Type = gsub("(.*)\\_(.*)\\_(.*)", "\\3", colnames(data))    
Type

design <- model.matrix(~0 + factor(Type))  
colnames(design) <- c("Control", "Disease")  

fit <- lmFit(data, design)  
cont.matrix <- makeContrasts(Disease - Control, levels=design)  
fit2 <- contrasts.fit(fit, cont.matrix)   
fit2 <- eBayes(fit2)

allDiff = topTable(fit2, adjust='fdr', number=200000) 
allDiffOut = rbind(id=colnames(allDiff), allDiff)     
write.table(allDiffOut, file="all_degs.txt", sep="\t", quote=F, col.names=F)

diffSig = allDiff[with(allDiff, (abs(logFC) > logFCfilter & P.Value < adj.P.Val.Filter)), ]
diffSigOut = rbind(id=colnames(diffSig), diffSig)  
write.table(diffSigOut, file="diff_significant_p0.05_FC1.5.txt", sep="\t", quote=F, col.names=F)


diffGeneExp = data[row.names(diffSig), ]  
diffGeneExpOut = rbind(id=paste0(colnames(diffGeneExp), "_", Type), diffGeneExp)  
write.table(diffGeneExpOut, file="diffGeneExp.txt", sep="\t", quote=F, col.names=F)

geneNum = 50  
diffUp = diffSig[diffSig$logFC > 0, ]    
diffDown = diffSig[diffSig$logFC < 0, ]  

geneUp = row.names(diffUp)[1:min(geneNum, nrow(diffUp))]        
geneDown = row.names(diffDown)[1:min(geneNum, nrow(diffDown))] 
hmExp = data[c(geneUp, geneDown), ]     

Type = as.data.frame(Type)
Type = cbind(Project, Type)  
rownames(Type) <- colnames(hmExp)

pdf(file="5_top50_DEG_heatmap.pdf", width=10, height=7)
pheatmap(hmExp,
         annotation_col = Type,          
         color = colorRampPalette(c("blue2", "white", "red2"))(50),  
         cluster_cols = F,             
         show_colnames = F,            
         scale = "row",               
         fontsize = 8,               
         fontsize_row = 5.5,          
         fontsize_col = 8)            
dev.off()

rt = read.table("all_degs.txt", header=T, sep="\t", check.names=F)

Sig = ifelse(
  (rt$P.Value < adj.P.Val.Filter) & (abs(rt$logFC) > logFCfilter),
  ifelse(rt$logFC > logFCfilter, "Up", "Down"),  
  "Not" 
)

rt = mutate(rt, Sig = Sig)  

rt$log2FoldChange <- rt$logFC
rt$padj <- rt$P.Value
rownames(rt) <- rt$id

VolcanoPlot <- function(dif, log2FC = 1, padj = 0.05, 
                        label.symbols = NULL, label.max = 30,
                        cols = c("#497aa2", "#ae3137"), title = ""){
  # define up and down
  dif$threshold <- "ns"  
  up_indices <- which(dif$log2FoldChange > log2FC & dif$padj < padj)
  dif$threshold[up_indices] <- "up"
  down_indices <- which(dif$log2FoldChange < -log2FC & dif$padj < padj)
  dif$threshold[down_indices] <- "down"
  dif$threshold <- factor(dif$threshold, levels = c('down', 'ns', 'up'))
  tb2 = table(dif$threshold)
  # plot
  color_manual <- c('down' = cols[1], 'ns' = "grey", 'up' = cols[2])
  labels_manual <- c('down' = paste0("down (", tb2[1], ")"), 'ns' = 'ns', 
                     'up' = paste0("up (", tb2[3], ")"))
  g1 = ggplot(data = dif, aes(x = log2FoldChange, y = -log10(padj), color = threshold)) +
    geom_point(alpha = 0.8, size = 0.8) +
    geom_vline(xintercept = c(-log2FC, log2FC), linetype = 2, color = "grey") +
    geom_hline(yintercept = -log10(padj), linetype = 2, color = "grey") +
    labs(title = ifelse("" == title, "", paste("DEG:", title))) +
    xlab(bquote(Log[2] * FoldChange)) +
    ylab(bquote(-Log[10] * italic(P.adj))) +
    theme_classic(base_size = 14) +
    theme(legend.box = "horizontal",
          legend.position = "top",
          legend.spacing.x = unit(0, 'pt'),
          legend.text = element_text(margin = margin(r = 20)),
          legend.margin = margin(b = -10, unit = "pt"),
          plot.title = element_text(hjust = 0.5, size = 10)) +
    scale_color_manual('', labels = labels_manual, values = color_manual) +
    guides(color = guide_legend(override.aes = list(size = 3, alpha = 1)))
  g1
  # label genes
  if (label.max > 0) {
    if (is.null(label.symbols)) {
      dif.sig = dif[which(dif$threshold != "ns"), ]
      len = nrow(dif.sig)
      if (len < label.max) {
        label.symbols = rownames(dif.sig)
      } else {
        dif.sig = dif.sig[order(dif.sig$log2FoldChange), ]
        dif.sig = rbind(dif.sig[1:(label.max / 2), ], dif.sig[(len - label.max / 2):len, ])
        
        label.symbols = rownames(dif.sig)
      }}
    dd_text = dif[label.symbols, ]
    # add text
    g1 + geom_text_repel(data = dd_text,
                         aes(x = log2FoldChange, y = -log10(padj), label = row.names(dd_text)),
                         color = "black", alpha = 1)
  } else {
    return(g1)
  }
}

VolcanoPlot(rt, log2FC = 0.585, padj = 0.05,label.max = 10)
ggsave('6_volcano_plot_log2FC1_p0.05.pdf', width = 7, height = 6)

### Neutrophil degranulation
library(ggprism)
library(ggrepel)

DEGs = rt

width <- c(.5, 1)
ymax <- max(-log10(DEGs$P.Value))
xmax <- max(abs(DEGs$logFC))
number <- 1000
rect.data <- expand.grid(
  x = seq(-xmax - width[2], xmax + width[2], 
          length.out = number),
  y = seq(-width[1], ymax + width[1], 
          length.out = number)
)

y_breaks <- scales::extended_breaks()(-log10(DEGs$P.Value))[-1]
DEGs <- DEGs %>% arrange(desc(logFC)) %>% mutate(rank = row_number())
top.data <- dplyr::filter(DEGs, P.Value < 0.05) %>% 
  group_by(logFC < 0) %>% top_n(10, abs(logFC))

pal <- c('#a3ad62','#fdfbe4', '#df91a3')
pal.grad <- colorRampPalette(pal[c(2, 1, 3)])(50)

pdf('degs_raster_gene.pdf', width = 5, height = 4)

DEGs %>%
  ggplot(aes(rank, logFC, colour = logFC)) +
  geom_point(
    aes(size = abs(logFC)), 
    alpha = 0.5, 
    show.legend = FALSE
  ) +
  geom_point(
    aes(size = abs(logFC)),
    data = top.data,
    fill = NA, colour = 'grey60',
    shape = 21,
    show.legend = FALSE
  ) +
  geom_label_repel(
    aes(label = id), 
    data = top.data,
    max.overlaps = 2000
  ) +
  labs(title = 'Neutrophil degranulation') +
  scale_colour_gradientn(colours = pal.grad) +
  ggprism::theme_prism() +
  theme(legend.title = element_text(size = 12))
dev.off()

### Venn
library(ggVennDiagram)

data_protein <- read.csv("diff_results.csv")
data_Neutrophil <- read.csv("GeneCards-Neutrophil degranulation.csv")
data_merge  <- intersect(data_Neutrophil$Gene.Symbol,data_protein$Gene)

set1 <- data_Neutrophil$Gene.Symbol
set2 <- data_protein$Gene

gene_list <- list(Set1 = set1, Set2 = set2)
ggVennDiagram(gene_list, label_alpha = 0, category.names = c("Set1", "Set2")) +
  scale_fill_gradient(low = "#B2DF8A", high = "#FF7F00") +
  theme(legend.position = "none")
ggsave("venn_plot.pdf", width = 6, height = 5)

table(data_merge %in% data_protein$Gene)
data <- data[data_merge,]
write.csv(data, 'test_normalized_filter.csv')


################################################################################
##### figure2 #####
# data integration
library(harmony)  

ZSZ_read <- function(file_path) {
  data <- read.csv(file_path, header = TRUE,row.names = 1)
  gene_names <- rownames(data)
  expr_matrix <- as.matrix(data)
  rownames(expr_matrix) <- gene_names
  deduped_expr <- collapse::fmean(expr_matrix, g = rownames(expr_matrix))
  return(deduped_expr)
}

expression_files <- list.files(pattern = "normalized\\.csv$")

if (length(expression_files) == 0) {
  stop("false")
}

gene_sets <- lapply(expression_files, function(file) {
  data <- ZSZ_read(file)
  rownames(data)
})


common_genes <- Reduce(intersect, gene_sets)

combined_data <- NULL
batch_info <- c()
sample_info <- c()

for (i in seq_along(expression_files)) {
  expr_data <- ZSZ_read(expression_files[i])
  samples <- colnames(expr_data)
  groups <- sapply(strsplit(samples, "_"), function(x) x[3])
  expr_subset <- expr_data[rownames(expr_data) %in% common_genes, ]
  if (is.null(combined_data)) {
    combined_data <- expr_subset
  } else {
    combined_data <- cbind(combined_data, expr_subset)
  }
  batch_info <- c(batch_info, rep(i, ncol(expr_subset)))
  sample_info <- c(sample_info, groups)
}

harmony_corrected <- HarmonyMatrix(
  data_mat = t(combined_data),
  meta_data = data.frame(Batch = factor(batch_info)),
  vars_use = "Batch",
  do_pca = TRUE
)

corrected_data <- t(harmony_corrected)
rownames(corrected_data) <- rownames(combined_data)
colnames(corrected_data) <- colnames(combined_data)
write.csv(corrected_data, 'combined_data_normalized.csv')

target_genes <- rownames(combined_data)
target_expr <- corrected_data[target_genes, , drop = FALSE]

sample_groups <- ifelse(sample_info == "Control", 0, 1)
is_train <- grepl("GSE125512|GSE24265", colnames(target_expr), ignore.case = TRUE)

create_dataset <- function(expr, groups, is_train_set) {
  df <- data.frame(t(expr[, is_train_set, drop = FALSE]))
  df$Group <- groups[is_train_set]
  return(df)
}

train_data <- create_dataset(target_expr, sample_groups, is_train)
test_data <- create_dataset(target_expr, sample_groups, !is_train)

write.table(train_data, file = "training_data.csv", 
            sep = ",", quote = FALSE, row.names = TRUE)
write.table(test_data, file = "testing_data.csv", 
            sep = ",", quote = FALSE, row.names = TRUE)
cat("train sample:", nrow(train_data), "\n")
cat("test sample:", nrow(test_data), "\n")
cat("feature gene:", ncol(train_data) - 1, "\n")

### ML
library(openxlsx)
library(seqinr)
library(plyr)
library(glmnet)
library(plsRglm)
library(gbm)
library(caret)
library(mboost)
library(e1071)
library(BART)
library(MASS)
library(snowfall)
library(xgboost)
library(ComplexHeatmap)
library(RColorBrewer)
library(pROC)
library(UpSetR)
library(randomForestSRC)

train_data <- read.csv("training_data.csv", row.names = 1, stringsAsFactors = FALSE)
train_features <- train_data[, -ncol(train_data), drop = FALSE]
train_labels <- train_data[, ncol(train_data),drop = F]

test_data <- read.csv("testing_data.csv", row.names = 1, stringsAsFactors = FALSE)
test_features <- test_data[, -ncol(test_data), drop = FALSE]
test_labels <- test_data[, ncol(test_data),drop = F]
test_labels$Cohort <- gsub("(.+)\\_(.+)\\_(.+)",'\\1',rownames(test_data))

common_features <- intersect(colnames(train_features), colnames(test_features))
train_data <- as.matrix(train_data[, common_features])
test_data <- as.matrix(test_data[, common_features])

train_data = scaleData(train_data, centerFlags=T, scaleFlags=T) 
test_data = scaleData(test_data, cohort = test_labels$Cohort, centerFlags = T, scaleFlags = T)

methods <- read.table("113_ML_methods.txt", header=T, sep="\t", check.names=F)
methods <- methods$x

classVar = "Group"        
min.selected.var = 3    
Variable = colnames(train_features)
preTrain.method =  c("Lasso","glmBoost","RF","Stepglm[both]","Stepglm[backward]")

preTrain.var <- list()      
set.seed(seed = 123)        

time.list <- list()
for (method in preTrain.method) {
  time.taken <- system.time({
    preTrain.var[[method]] <- RunML(
      method = method,
      Train_set = train_data,
      Train_label = train_labels,
      mode = "Variable",
      classVar = classVar
    )
  })
  time.list[[method]] <- time.taken[["elapsed"]]  
  cat(sprintf("Method [%s] took %.2f seconds\n", method, time.taken[["elapsed"]]))
}
preTrain.var[["simple"]] <- colnames(train_data)

gene_lists <- list(
  Lasso = preTrain.var$Lasso,
  glmBoost = preTrain.var$glmBoost,
  RF = preTrain.var$RF,
  Step_both = preTrain.var$`Stepglm[both]`,
  Step_back = preTrain.var$`Stepglm[backward]`
)

upset_data <- fromList(gene_lists)

allcolour=c('#DF0A1F','#1C5BA7','#019E73','#ED621B','#E477C1')

pdf("gene_intersection_upset.pdf", width=10, height=6)
upset(upset_data, sets = names(gene_lists), 
      order.by = "freq", 
      text.scale = 1.2,
      mainbar.y.label = "Gene number intersected",
      sets.x.label = "Gene number selected")
dev.off()

core_genes <- Reduce(intersect, gene_lists)
write.table(core_genes, "core_genes.txt", quote=FALSE, row.names=FALSE, col.names=FALSE)

methods
methods <- methods[!grepl('RF',methods)]

model <- list()            
set.seed(seed = 123)       
Train_set_bk = train_data
for (method in methods){
  cat(match(method, methods), ":", method, "\n")
  method_name = method
  method <- strsplit(method, "\\+")[[1]]
  if (length(method) == 1) method <- c("simple", method)
  Variable = preTrain.var[[method[1]]]
  train_data = Train_set_bk[, Variable]
  Train_label = train_labels
  model[[method_name]] <- RunML(method = method[2],           
                                Train_set = train_data,        
                                Train_label = train_labels,    
                                mode = "Model",               
                                classVar = classVar)
  if(length(ExtractVar(model[[method_name]])) <= min.selected.var) {
    model[[method_name]] <- NULL
  }
}
train_data = Train_set_bk; rm(Train_set_bk)
saveRDS(model, "model.MLmodel.rds")


model <- readRDS("model.MLmodel.rds")            
methodsValid <- names(model)                     
RS_list <- list()
for (method in methodsValid){
  RS_list[[method]] <- CalPredictScore(fit = model[[method]], 
                                       new_data = rbind.data.frame(train_data,test_data))
}
riskTab=as.data.frame(t(do.call(rbind, RS_list)))
riskTab=cbind(id=row.names(riskTab), riskTab)
write.table(riskTab, "model.riskMatrix.txt", sep="\t", row.names=F, quote=F)

Class_list <- list()
for (method in methodsValid){
  Class_list[[method]] <- PredictClass(fit = model[[method]], new_data = rbind.data.frame(train_data,test_data))
}
Class_mat <- as.data.frame(t(do.call(rbind, Class_list)))
classTab=cbind(id=row.names(Class_mat), Class_mat)
write.table(classTab, "model.classMatrix.txt", sep="\t", row.names=F, quote=F)

fea_list <- list()
for (method in methodsValid) {
  fea_list[[method]] <- ExtractVar(model[[method]])
}
fea_df <- lapply(model, function(fit){
  data.frame(ExtractVar(fit))
})
fea_df <- do.call(rbind, fea_df)
fea_df$algorithm <- gsub("(.+)\\.(.+$)", "\\1", rownames(fea_df))
colnames(fea_df)[1] <- "features"
write.table(fea_df, file="model.genes.txt", sep = "\t", row.names = F, col.names = T, quote = F)

AUC_list <- list()
for (method in methodsValid){
  AUC_list[[method]] <- RunEval(fit = model[[method]],      
                                Test_set = test_data,       
                                Test_label = test_labels,  
                                Train_set = train_data,    
                                Train_label = train_labels, 
                                Train_name = "Train",      
                                cohortVar = "Cohort",     
                                classVar = classVar)      
}
AUC_mat <- do.call(rbind, AUC_list)
aucTab=cbind(Method=row.names(AUC_mat), AUC_mat)
write.table(aucTab, "model.AUCmatrix.txt", sep="\t", row.names=F, quote=F)

### AUC
AUC_mat <- read.table("model.AUCmatrix.txt", header=T, sep="\t", check.names=F,
                      row.names=1, stringsAsFactors=F)

avg_AUC <- apply(AUC_mat, 1, mean)
avg_AUC <- sort(avg_AUC, decreasing = T)
AUC_mat <- AUC_mat[names(avg_AUC),]
fea_sel <- fea_list[[rownames(AUC_mat)[1]]]
avg_AUC <- as.numeric(format(avg_AUC, digits = 3, nsmall = 3))

CohortCol <- brewer.pal(n = ncol(AUC_mat), name = "Paired")
names(CohortCol) <- colnames(AUC_mat)

cellwidth = 1; cellheight = 0.5
hm <- SimpleHeatmap(Cindex_mat = AUC_mat,      
                    avg_Cindex = avg_AUC,      
                    CohortCol = CohortCol[1:2],     
                    barCol = "steelblue",      
                    cellwidth = cellwidth, cellheight = cellheight,   
                    cluster_columns = F, cluster_rows = F)     
pdf(file="ML_AUC_heatmap.pdf", width=cellwidth * ncol(AUC_mat) + 6, 
    height=cellheight * nrow(AUC_mat) * 0.45)
draw(hm, heatmap_legend_side="right", annotation_legend_side="right")
dev.off()

rsFile="model.riskMatrix.txt"      
method="Stepglm[backward]+GBM"            

riskRT=read.table(rsFile, header=T, sep="\t", check.names=F, row.names=1)
CohortID=gsub("(.*)\\_(.*)\\_(.*)", "\\1", rownames(riskRT))
CohortID=gsub("(.*)\\.(.*)", "\\1", CohortID)
CohortID <- ifelse(CohortID == 'Test','Test','Train')
riskRT$Cohort=CohortID

for(Cohort in unique(riskRT$Cohort)){
  rt=riskRT[riskRT$Cohort==Cohort,]
  y=gsub("(.*)\\_(.*)\\_(.*)", "\\3", row.names(rt))
  y=ifelse(y=="Control", 0, 1)
  roc1=roc(y, as.numeric(rt[,method]))      
  ci1=ci.auc(roc1, method="bootstrap")      
  ciVec=as.numeric(ci1)
  pdf(file=paste0("ROC.", Cohort, ".pdf"), width=5, height=4.75)
  plot(roc1, print.auc=TRUE, col= c("#B2DF8A","#FF7F00"), legacy.axes=T, main=Cohort)
  text(0.39, 0.43, paste0("95% CI: ",sprintf("%.03f",ciVec[1]),"-",
                          sprintf("%.03f",ciVec[3])), col="red")
  dev.off()
}

genes <- read.table("model.genes.txt", header = TRUE)
model_gene <- genes$features[genes$algorithm == 'Stepglm[backward]+GBM']
write.table(model_gene, 'best_method_model_gene.txt', sep = "\t", 
            row.names = FALSE, col.names = TRUE, quote = FALSE)

expFile <- "merged_normalized_train_data.txt"
geneFile <- "best_method_model_gene.txt"

rt <- read.table(expFile, header = TRUE, sep = "\t", 
                 check.names = FALSE, row.names = 1)

y <- gsub("(.*)\\_(.*)\\_(.*)", "\\3", colnames(rt))
y <- ifelse(y == "Control", 0, 1)

bioCol <- rainbow(length(model_gene), s = 0.9, v = 0.9)
gene_aucs <- data.frame(Gene = character(), AUC = numeric(), stringsAsFactors = FALSE)


pdf(file = "ROC.genes.pdf", width = 9, height = 9)
for (i in seq_along(model_gene)) {
  x <- model_gene[i]
  if (!x %in% rownames(rt)) {
    warning(paste("Gene", x, "not found in expression data. Skipping."))
    next
  }
  roc1 <- roc(y, as.numeric(rt[x, ]))
  gene_aucs <- rbind(gene_aucs, data.frame(Gene = x, AUC = roc1$auc[1]))
  if (i == 1) {
    plot(roc1, print.auc = FALSE, col = bioCol[i], 
         legacy.axes = TRUE, main = "", lwd = 3)
  } else {
    plot(roc1, print.auc = FALSE, col = bioCol[i], 
         legacy.axes = TRUE, main = "", lwd = 3, add = TRUE)
  }
}

aucText <- paste0(gene_aucs$Gene, ", AUC=", sprintf("%.3f", gene_aucs$AUC))
legend("bottomright", aucText, lwd = 3, bty = "n", 
       cex = 0.8, col = bioCol[1:nrow(gene_aucs)],
       inset = c(0.05, 0))
dev.off()

gene_aucs <- gene_aucs[order(-gene_aucs$AUC), ]
top_genes <- gene_aucs$Gene[1:min(10, nrow(gene_aucs))] 

model_data <- data.frame(
  Status = as.factor(y),
  t(rt[top_genes, , drop = FALSE])
)

combined_model <- glm(
  Status ~ .,
  data = model_data,
  family = binomial()
)

predicted_probs <- predict(combined_model, type = "response")
model_data$Predicted_Probability <- predicted_probs

combined_roc <- roc(model_data$Status, model_data$Predicted_Probability)
combined_auc <- combined_roc$auc[1]

best_single_gene <- gene_aucs$Gene[which.max(gene_aucs$AUC)]
best_single_auc <- gene_aucs$AUC[which.max(gene_aucs$AUC)]

pdf("Combined_vs_Best_Gene_ROC.pdf", width = 7, height = 7)
plot(combined_roc, col = "#B2DF8A", lwd = 3, legacy.axes = TRUE,
     main = "Combined Model vs Best Single Gene")

best_gene_roc <- roc(y, as.numeric(rt[best_single_gene, ]))
plot(best_gene_roc, col = "#FF7F00", lwd = 2, lty = 2, add = TRUE)

legend("bottomright", 
       legend = c(
         sprintf("Combined Model (AUC = %.3f)", combined_auc),
         sprintf("Best Single Gene: %s (AUC = %.3f)", best_single_gene, best_single_auc)
       ),
       col = c("#B2DF8A", "#FF7F00"), lwd = c(3, 2), lty = c(1, 2))
dev.off()

coef_df <- data.frame(
  Gene = names(coef(combined_model))[-1],  
  Coefficient = coef(combined_model)[-1]
)

coef_df <- rbind(
  coef_df,
  data.frame(Gene = "Combined_Model", Coefficient = combined_auc)
)

write.table(coef_df, "Diagnosis_Model_Results.txt", sep = "\t",
            quote = FALSE, row.names = FALSE)

test <- read.table("model.genes.txt",header = T)
head(test)

gene_counts <- table(test$features)
gene_counts_df <- as.data.frame(gene_counts)
colnames(gene_counts_df) <- c("Gene", "Frequency")
gene_counts_df <- gene_counts_df[order(-gene_counts_df$Frequency), ]
print(gene_counts_df)
write.csv(gene_counts_df,'gene_counts.csv')

###
library(rms)
library(pROC)
library(ggplot2)

expFile <- "merged_normalized_train_data.txt"
geneFile <- "best_method_model_gene.txt"

rt <- read.table(expFile, header = TRUE, sep = "\t", check.names = FALSE, row.names = 1)
model_gene <- read.table(geneFile, header = FALSE, stringsAsFactors = FALSE)[, 1]

y <- gsub("(.*)\\_(.*)\\_(.*)", "\\3", colnames(rt))
y <- ifelse(y == "Control", 0, 1)

exp <- as.data.frame(t(rt[model_gene, ]))
exp$Group <- as.factor(y)
exp <- exp[, -1]
model <- glm(Group ~ CD55+AGT+EGF+ANXA1+CTSD+APOA2+ENO1+CD14+APOA1+FGA, data = exp, family = binomial)

summary(model)
dd <- datadist(exp)
options(datadist = "dd")
fit <- lrm(Group ~ CD55+AGT+EGF+ANXA1+CTSD+APOA2+ENO1+CD14+APOA1+FGA, data = exp)

nom <- nomogram(fit, fun = plogis, fun.at = c(0.1, 0.5, 0.9), lp = TRUE)
pdf("Nomogram.multi_gene.pdf", width = 10, height = 8)
plot(nom, xfrac = 0.4)
dev.off()

pred_prob <- predict(model, type = "response")

roc_obj <- roc(exp$Group, pred_prob)
auc_val <- auc(roc_obj)
ci_val <- ci.auc(roc_obj)

pdf("ROC.multi_gene_model.pdf", width = 6, height = 6)
plot(roc_obj, col = "#D51F26", lwd = 2, main = "Combined Model ROC")
legend("bottomright", legend = paste0("AUC = ", sprintf("%.3f", auc_val),
                                      ", 95% CI: ", sprintf("%.3f", ci_val[1]),
                                      "–", sprintf("%.3f", ci_val[3])),
       col = "#D51F26", lwd = 2, bty = "n")
dev.off()

coefs <- summary(model)$coefficients[-1, ]
coef_df <- data.frame(
  Gene = rownames(coefs),
  Coef = coefs[, "Estimate"],
  pvalue = coefs[, "Pr(>|z|)"]
)

pdf("Coef.multi_gene_model.pdf", width = 7, height = 5)
ggplot(coef_df, aes(x = reorder(Gene, Coef), y = Coef, fill = Coef > 0)) +
  geom_bar(stat = "identity", width = 0.6) +
  coord_flip() +
  scale_fill_manual(values = c("#B2DF8A", "#FF7F00")) +
  theme_minimal() +
  labs(x = "", y = "Regression Coefficient", title = "Logistic Regression Coefficients") +
  theme(legend.position = "none")
dev.off()

model_gene <- c( "CD55","AGT","EGF","ANXA1","CTSD","APOA2","ENO1","CD14","APOA1","FGA")
bioCol <- rainbow(length(model_gene), s = 0.9, v = 0.9)
gene_aucs <- data.frame(Gene = character(), AUC = numeric(), stringsAsFactors = FALSE)
pdf(file = "ROC.genes.pdf", width = 9, height = 9)
for (i in seq_along(model_gene)) {
  x <- model_gene[i]
  if (!x %in% rownames(rt)) {
    warning(paste("Gene", x, "not found in expression data. Skipping."))
    next
  }
  roc1 <- roc(y, as.numeric(rt[x, ]))
  gene_aucs <- rbind(gene_aucs, data.frame(Gene = x, AUC = roc1$auc[1]))
  if (i == 1) {
    plot(roc1, print.auc = FALSE, col = bioCol[i], 
         legacy.axes = TRUE, main = "", lwd = 3)
  } else {
    plot(roc1, print.auc = FALSE, col = bioCol[i], 
         legacy.axes = TRUE, main = "", lwd = 3, add = TRUE)
  }
}

aucText <- paste0(gene_aucs$Gene, ", AUC=", sprintf("%.3f", gene_aucs$AUC))
legend("bottomright", aucText, lwd = 3, bty = "n", 
       cex = 0.8, col = bioCol[1:nrow(gene_aucs)],
       inset = c(0.05, 0))
dev.off()

################################################################################
##### figure3 #####
library(Seurat)
library(data.table)
library(dplyr)
library(tidyverse)
library(Matrix)
library(stringr)
library(ggplot2)
library(clustree)
library(cowplot)
library(harmony)

dir='GSE266873_RAW/'
fs=list.files('GSE266873_RAW/','^GSM')
fs
samples=str_split(fs,'_',simplify=T)[,1]

lapply(unique(samples),function(x){
  #x=unique(samples)[1]
  y=fs[grepl(x,fs)]
  folder=paste0("GSE266873_RAW/",paste(str_split(y[1],'_',simplify=T)[,1:2],collapse="_"))
  dir.create(folder,recursive=T)
  file.rename(paste0("GSE266873_RAW/",y[1]),file.path(folder,"barcodes.tsv.gz"))
  file.rename(paste0("GSE266873_RAW/",y[2]),file.path(folder,"features.tsv.gz"))
  file.rename(paste0("GSE266873_RAW/",y[3]),file.path(folder,"matrix.mtx.gz"))
})

samples=list.files(dir)
samples
sceList=lapply(samples,function(pro){
  #pro=samples[1]
  print(pro)
  tmp=Read10X(file.path(dir,pro))
  if(length(tmp)==2){
    ct=tmp[[1]]
  }else{ct=tmp}
  sce=CreateSeuratObject(counts=ct,
                         project=pro,
                         min.cells=5,
                         min.features=300)
  return(sce)
})
View(sceList)

PT1<-sceList[1]
View(PT1)

do.call(rbind,lapply(sceList,dim))
sce.all=merge(x=sceList[[1]],
              y=sceList[-1],
              add.cell.ids=samples)
names(sce.all@assays$RNA@layers)
sce.all[["RNA"]]$counts

LayerData(sce.all,assay="RNA",layer="counts")
layers <- Layers(sce.all)

sample1 <- GetAssayData(sce.all, layer = "counts.GSM8255340_sample1")
sample2 <- GetAssayData(sce.all, layer = "counts.GSM8255341_sample1")
sample3 <- GetAssayData(sce.all, layer = "counts.GSM8255342_sample1")
sample4 <- GetAssayData(sce.all, layer = "counts.GSM8255343_sample2")
sample5 <- GetAssayData(sce.all, layer = "counts.GSM8255344_sample2")
sample6 <- GetAssayData(sce.all, layer = "counts.GSM8255345_sample2")
sample7 <- GetAssayData(sce.all, layer = "counts.GSM8255346_sample3")
sample8 <- GetAssayData(sce.all, layer = "counts.GSM8255347_sample3")
sample9 <- GetAssayData(sce.all, layer = "counts.GSM8255348_sample3")

seurat1 <- CreateSeuratObject(counts = sample1, project = "Sample1")
seurat2 <- CreateSeuratObject(counts = sample2, project = "Sample2")
seurat3 <- CreateSeuratObject(counts = sample3, project = "sample3")
seurat4 <- CreateSeuratObject(counts = sample4, project = "sample4")
seurat5 <- CreateSeuratObject(counts = sample5, project = "sample5")
seurat6 <- CreateSeuratObject(counts = sample6, project = "sample6")
seurat7 <- CreateSeuratObject(counts = sample7, project = "sample7")
seurat8 <- CreateSeuratObject(counts = sample8, project = "sample8")
seurat9 <- CreateSeuratObject(counts = sample9, project = "sample9")

combined <- merge(
  x = seurat1,
  y = list(seurat2, seurat3, seurat4, seurat5, 
           seurat6, seurat7, seurat8, seurat9),
  add.cell.ids = c("S1", "S2", "S3", "S4", "S5", 
                   "S6", "S7", "S8", "S9"),
  project = "GSE266873"
)

sce.all<-combined
sce.all

dim(sce.all[["RNA"]]$counts)
as.data.frame(sce.all@assays$RNA$counts[1:9,1:2])
head(sce.all@meta.data,9)
table(sce.all$orig.ident)
length(sce.all$orig.ident)

phe=sce.all@meta.data
table(phe$orig.ident)
View(phe)

phe$group=str_split(phe$orig.ident,'[_]',simplify=T)[,1]

phe$sample=phe$orig.ident
phe$sample=gsub("GSM8255340|GSM8255341|GSM8255342","ICH_6h",phe$sample)
phe$sample=gsub("GSM8255343|GSM8255344|GSM8255345","ICH_24h",phe$sample)
phe$sample=gsub("GSM8255346|GSM8255347|GSM8255348","ICH_48h",phe$sample)
table(phe$sample)

phe$patient=phe$orig.ident
table(phe$patient)
phe$patient=gsub("GSM8255340","Patient1_2h",phe$patient)
phe$patient=gsub("GSM8255341","Patient2_3h",phe$patient)
phe$patient=gsub("GSM8255342","Patient3_2h",phe$patient)
phe$patient=gsub("GSM8255343","Patient4_12h",phe$patient)
phe$patient=gsub("GSM8255344","Patient5_12h",phe$patient)
phe$patient=gsub("GSM8255345","Patient6_12h",phe$patient)
phe$patient=gsub("GSM8255346","Patient7_26h",phe$patient)
phe$patient=gsub("GSM8255347","Patient8_28h",phe$patient)
phe$patient=gsub("GSM8255348","Patient9_32h",phe$patient)
table(phe$patient)

sce.all@meta.data=phe
sce.all
sce.all <- JoinLayers(sce.all)
sce.all
saveRDS(sce.all, file = "GSE266873.rds")


mito_genes=rownames(sce.all)[grep("^MT-",rownames(sce.all),ignore.case=T)]
print(mito_genes) 
sce.all=PercentageFeatureSet(sce.all,features=mito_genes,col.name="percent_mito")
fivenum(sce.all@meta.data$percent_mito)

ribo_genes=rownames(sce.all)[grep("^Rp[sl]",rownames(sce.all),ignore.case=T)]
print(ribo_genes)
sce.all=PercentageFeatureSet(sce.all,features=ribo_genes,col.name="percent_ribo")
fivenum(sce.all@meta.data$percent_ribo)

Hb_genes=rownames(sce.all)[grep("^Hb[^(p)]",rownames(sce.all),ignore.case=T)]
print(Hb_genes)
sce.all=PercentageFeatureSet(sce.all,features=Hb_genes,col.name="percent_hb")
fivenum(sce.all@meta.data$percent_hb)
head(sce.all@meta.data)

feats<-c("nFeature_RNA","nCount_RNA","percent_mito",
         "percent_ribo","percent_hb")
feats<-c("nFeature_RNA","nCount_RNA")
p1=VlnPlot(sce.all,group.by="orig.ident",features=feats,pt.size=0,ncol=2)+
  NoLegend()
p1
w=length(unique(sce.all$orig.ident))/3+5;w
ggsave(filename="Vlnplot1.pdf",plot=p1,width=w,height=5)
feats<-c("percent_mito","percent_ribo","percent_hb")
p2=VlnPlot(sce.all,group.by="orig.ident",features=feats,pt.size=0,ncol=3,same.y.lims=T)+
  scale_y_continuous(breaks=seq(0,100,5))+
  NoLegend()
p2
w=length(unique(sce.all$orig.ident))/2+5;w
ggsave(filename="Vlnplot2.pdf",plot=p2,width=w,height=5)
p3=FeatureScatter(sce.all,"nCount_RNA","nFeature_RNA",group.by="orig.ident",pt.size=0.5)
p3
ggsave(filename="Scatterplot.pdf",plot=p3)

selected_c<-WhichCells(sce.all,expression= nFeature_RNA > 200 & nFeature_RNA < 6000)
selected_f<-rownames(sce.all)[Matrix::rowSums(sce.all@assays$RNA$counts>0)>3]
sce.all.filt<-subset(sce.all,features=selected_f,cells=selected_c)
dim(sce.all)
dim(sce.all.filt)

sce.all.filt=sce.all
C=subset(sce.all.filt,downsample=100)@assays$RNA$counts
dim(C)
C=Matrix::t(Matrix::t(C)/Matrix::colSums(C))*100
most_expressed<-order(apply(C,1,median),decreasing=T)[50:1]
pdf("TOP50_most_expressed_gene.pdf",width=14)
boxplot(as.matrix(Matrix::t(C[most_expressed,])),
        cex=0.1,las=1,
        xlab="%total countper cell",
        col=(scales::hue_pal())(50)[50:1],
        horizontal=TRUE)

selected_mito<-WhichCells(sce.all.filt,expression=percent_mito<10)
length(selected_mito)
sce.all.filt<-subset(sce.all.filt,cells=selected_mito)
dim(sce.all.filt)
table(sce.all.filt$orig.ident)
length(sce.all.filt$orig.ident)

feats<-c("nFeature_RNA","nCount_RNA")
p1_filtered=VlnPlot(sce.all.filt,group.by="orig.ident",features=feats,pt.size=0,ncol=2)+
  NoLegend()
w=length(unique(sce.all.filt$orig.ident))/3+5;w
ggsave(filename="Vlnplot1_filtered.pdf",plot=p1_filtered,width=w,height=5)
feats<-c("percent_mito","percent_ribo","percent_hb")
p2_filtered=VlnPlot(sce.all.filt,group.by="orig.ident",features=feats,pt.size=0,ncol=3)+
  NoLegend()
w=length(unique(sce.all.filt$orig.ident))/2+5;w
ggsave(filename="Vlnplot2_filtered.pdf",plot=p2_filtered,width=w,height=5)

sce.all.filt<-NormalizeData(sce.all.filt,
                            normalization.method="LogNormalize",
                            scale.factor=1e4)
sce.all.filt<-FindVariableFeatures(sce.all.filt)
p4<-VariableFeaturePlot(sce.all.filt)
p4
ggsave(filename="VariableFeature.pdf",plot=p4,width=w,height=5)

sce.all.filt<-ScaleData(sce.all.filt)
sce.all.filt<-RunPCA(sce.all.filt,features=VariableFeatures(object=sce.all.filt))
VizDimLoadings(sce.all.filt,dims=1:2,reduction="pca")
DimPlot(sce.all.filt,reduction="pca")+NoLegend()
DimHeatmap(sce.all.filt,dims=1:12,cells=500,balanced=TRUE)
saveRDS(sce.all.filt, file = "GSE266873_filt.rds")

seuratObj<-RunHarmony(sce.all,"orig.ident")
names(seuratObj@reductions)
seuratObj<-RunUMAP(seuratObj,dims=1:15,
                   reduction="harmony")
DimPlot(seuratObj,reduction="umap",label=F)
seuratObj<-RunTSNE(seuratObj,dims=1:15,
                   reduction="harmony")
DimPlot(seuratObj,reduction="tsne",label=F)

sce.all.filt=seuratObj
sce.all.filt<-FindNeighbors(sce.all.filt,reduction="harmony",
                            dims=1:15)
sce.all.filt.all=sce.all.filt

for(res in c(0.01, 0.05, 0.1, 0.2, 0.3, 0.5,0.8,1)) {
  sce.all.filt.all=FindClusters(sce.all.filt.all, #graph.name = "CCA_snn", 
                                resolution = res, algorithm = 1)
}
colnames(sce.all.filt.all@meta.data)
apply(sce.all.filt.all@meta.data[,grep("RNA_snn",colnames(sce.all.filt.all@meta.data))],2,table)
p1_dim=plot_grid(ncol = 3, DimPlot(sce.all.filt.all, reduction = "umap", group.by = "RNA_snn_res.0.8") + 
                   ggtitle("louvain_0.8"), DimPlot(sce.all.filt.all, reduction = "umap", group.by = "RNA_snn_res.1") + 
                   ggtitle("louvain_1"), DimPlot(sce.all.filt.all, reduction = "umap", group.by = "RNA_snn_res.0.3") + 
                   ggtitle("louvain_0.3"))
ggsave(plot=p1_dim, filename="Dimplot_diff_resolution_high.pdf",width = 18)

p2_tree=clustree(sce.all.filt.all@meta.data, prefix = "RNA_snn_res.")
ggsave(plot=p2_tree, filename="Tree_diff_resolution.pdf")
table(sce.all.filt.all@active.ident) 
saveRDS(sce.all.filt.all, file = "GSE266873_filt_harmony.rds")

# annotation
sce.all.int=readRDS("GSE266873_filt_harmony.rds")
sel.clust="RNA_snn_res.0.5"
sce.all.int<-SetIdent(sce.all.int,value=sel.clust)
table(sce.all.int@active.ident)
colnames(sce.all.int@meta.data)

dir.create("./3-Celltype")
setwd("./3-Celltype")
scRNA=sce.all.int

genes_to_check= c('EGFL7','VWF','CLDN5', 'RGS5', # endothelial cell
                  'GZMB', 'GZMA', 'NKG7', 'CD3E','CD3D', # NK/T cell
                  'FCGR3B', 'CXCR2', 'S100A8', 'CSF3R', # neutrophil
                  'VCAN' , 'CD300E',  # monocyte
                  'PDGFRA', 'CSPG4', # neuron
                  'AQP4', 'ATP1B2', 'ALDH1L1', # astrocyte
                  'ADORA3' ,'CX3CR1', 'TMEM119', 'CSF1R', # microglia
                  'HAPLN2', 'CNP','SOX10','MOG') # oligodendrocyte
p = DotPlot(scRNA, features = unique(genes_to_check),
            assay='RNA' ) + coord_flip()
p
ggsave(plot=p, filename="p_markers.pdf",width = 18)

marker_data <- p$data
head(marker_data)
library(tidyr)
marker_wide <- marker_data %>%
  select(features.plot, id, avg.exp) %>%
  pivot_wider(names_from = id, values_from = avg.exp)
write.csv(marker_wide, file = "marker_genes_expression.csv", row.names = FALSE)

mycolors <-c('#E64A35','#4DBBD4' ,'#01A187' ,'#6BD66B','#3C5588' ,'#F29F80' ,
             '#8491B6','#91D0C1','#7F5F48','#AF9E85','#4F4FFF','#CE3D33',
             '#739B57','#EFE685','#446983','#BB6239','#5DB1DC','#7F2268','#800202',
             '#D8D8CD','#D2CDFA','#FACAAE')

tsne =DimPlot(scRNA, reduction = "tsne",cols = mycolors,pt.size = 0.8,
              group.by = "RNA_snn_res.0.5",label = T,label.box = T)
tsne
ggsave(plot=tsne, filename="tsne_markers.pdf",width = 18)

celltype=data.frame(ClusterID=c(0,1,2,3,4,5,6,7,8,9,10,11,13,15),
                    celltype=c(0,1,2,3,4,5,6,7,8,9,10,11,13,15))
celltype[celltype$ClusterID %in% c( 0,3,4,9,11),2]='Oligodendrocyte'
celltype[celltype$ClusterID %in% c( 1,6,15),2]='Microglia_cell'
celltype[celltype$ClusterID %in% c(8),2]='Astrocyte'
celltype[celltype$ClusterID %in% c( 10),2]='Neural_progenitor'
celltype[celltype$ClusterID %in% c( 5 ),2]='Monocyte'
celltype[celltype$ClusterID %in% c( 7 ),2]='NK_T_cell'
celltype[celltype$ClusterID %in% c( 13 ),2]='endothelial_cell'
celltype[celltype$ClusterID %in% c( 2 ),2]='Neutrophil'

scRNA@meta.data$celltype <- "NA"
for (i in 1:nrow(celltype)) {
  scRNA@meta.data[scRNA@meta.data$RNA_snn_res.0.5 == celltype$ClusterID[i], 
                  "celltype"] <- celltype$celltype[i]}

scRNA <- subset(scRNA, subset = celltype != "NA")
Idents(scRNA) <- scRNA$celltype
th <- theme(axis.text.x = element_text(angle = 45, vjust = 0.5, hjust = 0.5))
mycolors <- c('#E64A35','#4DBBD4' ,'#01A187' ,'#6BD66B','#3C5588' ,'#F29F80' ,
              '#8491B6','#91D0C1','#7F5F48','#AF9E85','#4F4FFF','#CE3D33',
              '#739B57','#EFE685','#446983','#BB6239','#5DB1DC','#7F2268','#800202')

p_umap <- DimPlot(scRNA, reduction = "umap", group.by = "celltype", label = TRUE,
                  label.box = TRUE, cols = mycolors) + th
ggsave("umap_celltype.pdf", plot = p_umap, width = 10, height = 7)

p_tsne <- DimPlot(scRNA, reduction = "tsne", group.by = "celltype", label = TRUE,
                  label.box = TRUE, cols = mycolors) + th
ggsave("tsne_celltype.pdf", plot = p_tsne, width = 10, height = 7)
table(scRNA@meta.data$celltype)
saveRDS(scRNA,"sce_celltype.rds")

# plot
library(SCP)
library(Seurat)
library(DT)
library(COSG)
library(dplyr)
library(scRNAtoolVis)
library(data.table)
library(readr)
library(dplyr)
library(plyr)
library(ggpubr)
library(ggplot2)
library(patchwork)
library(dplyr)
mycolor <- c("#A6CEE3", "#1F78B4", "#B2DF8A", "#33A02C", "#FB9A99", 
             "#E31A1C", "#FDBF6F", "#FF7F00", "#CAB2D6", "#4DBBD5FF", 
             "#E64B35FF", "#00A087FF", "#3C5488FF", "#F39B7FFF", "#8491B4FF", 
             "#91D1C2FF", "#DC0000FF", "#7E6148FF", "#BC3C29FF", "#0072B5FF", 
             "#E18727FF", "#D24B27", "#D51F26", "#272E6A", "#208A42", "#89288F", 
             "#F47D2B", "#FEE500", "#8A9FD1", "#C06CAB", "#E6C2DC", "#90D5E4", 
             "#89C75F", "#F37B7D", "#9983BD", "#3BBCA8", "#6E4B9E", "#0C727C", 
             "#7E1416", "#D8A767", "#3D3D3D")

sce = readRDS("sce_celltype.rds")
table(sce$celltype)
Idents(sce) <- 'celltype'
ann=c('Neutrophil', 'Monocyte', 'NK_T_cell', 'Oligodendrocyte', 
      'Astrocyte', 'endothelial_cell', 'Microglia_cell','Neural_progenitor')

sce$celltype <- factor(sce$celltype,levels = ann)
table(sce$celltype, useNA = "ifany")

gene=c('EGFL7','VWF','CLDN5', 'RGS5', # endothelial cell
       'GZMB', 'GZMA', 'NKG7', 'CD3E','CD3D', # NK/T cell
       'FCGR3B', 'CXCR2', 'S100A8', 'CSF3R', # neutrophil
       'VCAN' , 'CD300E',  # monocyte
       'PDGFRA', 'CSPG4', # neuron
       'AQP4', 'ATP1B2', 'ALDH1L1', # astrocyte
       'ADORA3' ,'CX3CR1', 'TMEM119', 'CSF1R', # microglia
       'HAPLN2', 'CNP','SOX10','MOG') # oligodendrocyte

jjDotPlot(object = sce,assay='RNA',slot='data',
          gene = gene,  id = 'celltype', 
          split.by.aesGroup =T, 
          xtree = F,ytree = F,
          rescale = T,rescale.min = -2,rescale.max =2,   midpoint = 0, dot.col = c('grey','white','#E18727FF'),
          point.geom = T,point.shape = 21,tile.geom = F)
ggsave(file='dotplotann.pdf', dpi =300, height =5, width =6)          

SCP::CellDimPlot(
  srt = sce, group.by = "celltype",
  reduction = "UMAP", bg_color = "white",
  pt.size = 2,pt.alpha = 1,raster = T,
  palcolor=mycolor,
  # split.by = 'sample',
  label = F,label.size =4,label_insitu = TRUE,label_repel = F,
  add_density = F, 
  theme_use = "theme_blank"
)
ggsave(file='dim.pdf', dpi =300, height =6, width =8)

meta.tb = sce@meta.data
dat.plot = data.table(meta.tb)
dat.plot$Celltype = dat.plot$celltype
dat.plot$Group = factor(dat.plot$sample,levels = c('ICH_6h','ICH_24h', 'ICH_48h'))
dat.plot$SampleID = dat.plot$orig.ident
dat.plot <- dat.plot[,.(N=.N),by=c("SampleID","Celltype","Group")]
sum.data <- dat.plot[,{.(NTotal = sum(.SD$N))},by=c("SampleID","Group")]
dat.plot = left_join(dat.plot,sum.data)
dat.plot$freq = dat.plot$N / dat.plot$NTotal *100
head(dat.plot)

compraisions.list = list(
  c("ICH_6h", "ICH_24h"),
  c("ICH_6h", "ICH_48h"),
  c("ICH_24h", "ICH_48h")
)
g.colSet = list(group = c("ICH_6h" = mycolor[1], "ICH_24h" = mycolor[2], "ICH_48h" = mycolor[3]))
p.list.perMcls <- lapply(unique(sort(dat.plot$Celltype)), function(mcls) {
  text.size = 10
  text.angle = 45
  text.hjust = 1
  legend.position = "none"
  p <- ggboxplot(dat.plot[Celltype == mcls, ], x = "Group", y = "freq",
                 color = "Group", legend = "none", title = mcls,
                 xlab = "", ylab = "frequency",
                 add = "jitter", outlier.shape = NA) +
    scale_color_manual(values = g.colSet$group) +
    scale_fill_manual(values = g.colSet$group) +
    stat_compare_means(label = "p.format", comparisons = compraisions.list) +
    coord_cartesian(clip = "off") +
    theme(
      plot.title = element_text(size = text.size + 2, color = "black", hjust = 0.5),
      axis.ticks = element_line(color = "black"),
      axis.title = element_text(size = text.size, color = "black"), 
      axis.text = element_text(size = text.size, color = "black"),
      axis.text.x = element_text(angle = text.angle, hjust = text.hjust), 
      legend.position = legend.position,
      legend.text = element_text(size = text.size),
      legend.title = element_text(size = text.size),
      strip.background = element_rect(color = "black", linewidth = 1, linetype = "solid") 
    )
  return(p)
})

p.prop = wrap_plots(p.list.perMcls, ncol = 4)
p.prop
ggsave(p.prop,filename = "cellratio.pdf",width =23,height =6,units = "cm")

### gene expression
library(Seurat)
library(dplyr)
library(ggplot2)
library(SCP)
library(scCustomize)
library(ClusterGVis)
library(ggpubr)
library(patchwork)
library(RColorBrewer) 

pbmc <- readRDS("sce_celltype.rds")
table(pbmc$group)
table(pbmc$sample)
pbmc$sample <- ifelse(pbmc$sample == 'ICH_6h','G1',
                      ifelse(pbmc$sample == 'ICH_24h','G2','G3'))
table(pbmc$sample)

genes <- c("CD55","AGT","EGF","ANXA1","CTSD","APOA2","ENO1","CD14","APOA1","FGA")

comparelist <- list(c('G1','G2'),
                    c('G1','G3'),
                    c('G2','G3'))
pbmc <- Convert_Assay(pbmc,convert_to = 'v3')

p1 = FeatureStatPlot(pbmc,stat.by = genes,group.by = 'sample',
                comparisons = comparelist,add_box  = T,add_trend = F)
p1
ggsave('Vlnplot.pdf',p1,width = 10, height = 9.5)

color = c('#FCB25A','#FD6C07','#F18685')
p2 = FeatureStatPlot(pbmc,stat.by = genes,group.by = 'sample',
                comparisons = comparelist,add_box  = T,add_trend = F,
                plot_type = 'dot',palcolor = color,bg.by = 'sample')
p2
ggsave('Dotplot.pdf',p2,width = 10, height = 9.5)

p3 = FeatureStatPlot(pbmc,stat.by = genes,group.by = 'sample',
                comparisons = comparelist,add_box  = F,add_trend = F,
                plot_type = 'dot',palcolor = color,bg.by = 'sample')
p3
ggsave('Dotplot2.pdf',p3,width = 10, height = 9.5)

Idents(pbmc) <- 'celltype'
pdf('Heatmap.pdf',width = 6.73, height = 5.45)
ht <- GroupHeatmap(  srt = pbmc,
                     group.by = "celltype",
                     features = genes, 
                     height = 2,
                     width = 4, 
                     feature_split_palette = "simspec", 
                     group_palcolor = list(rainbow(length(unique(pbmc$celltype)))),
                     feature_split_palcolor = NULL,  
                     heatmap_palette = "YlOrRd"  
)
dev.off()

markergene <- c("CD55","AGT","EGF","ANXA1","CTSD","ENO1","CD14","APOA1")
plots <- lapply(markergene, function(gene) {
  SCP::FeatureDimPlot(
    srt = pbmc,
    features = gene,
    reduction = "UMAP",
    pt.size = 2.5,
    pt.alpha = 1,
    raster = TRUE,
    theme_use = "theme_blank",
    bg_color = "grey90",
    palcolor = c("#E8E8E8","#F47D2B"),
    label = FALSE
  )
})
patchwork::wrap_plots(plots, ncol = 5)
print(plots)
ggsave('UMAP.pdf',plots, width = 11.5, height = 7.63)

### scTOUR
library(SeuratDisk)
library(reticulate)
library(scCustomize)
library(Seurat)
sce = readRDS("sce_celltype.rds")

Assays(sce)
DefaultAssay(sce) <- 'RNA'
DimPlot(sce,group.by = 'celltype',label = T)
as.anndata(x = sce, file_path = "./",
           file_name ="sce.h5ad", assay = "RNA", 
           main_layer = "counts", other_layers = c("data"), 
           transfer_dimreduc = TRUE, verbose = TRUE)

################################################################################
library(Seurat)
library(ggplot2)
library(clustree)
library(cowplot)
library(data.table)
library(dplyr)
library(harmony)

sce <- readRDS("Neu_cg_sce.rds")
sce <- FindNeighbors(sce,reduction="harmony", dims=1:15)
for(res in c(0.1,0.3,0.5,0.8,1,3)) {sce=FindClusters(sce,resolution = res, algorithm = 1)}
colnames(sce@meta.data)
apply(sce@meta.data[,grep("RNA_snn",colnames(sce@meta.data))],2,table)

p1_dim=plot_grid(ncol = 3, DimPlot(sce, reduction = "umap", group.by = "RNA_snn_res.0.1") + 
                   ggtitle("louvain_0.1"), DimPlot(sce, reduction = "umap", group.by = "RNA_snn_res.0.3") + 
                   ggtitle("louvain_0.3"), DimPlot(sce, reduction = "umap", group.by = "RNA_snn_res.0.5") + 
                   ggtitle("louvain_0.5"))
p1_dim
ggsave(plot=p1_dim, filename="Neu_Dimplot_diff_resolution_low.pdf",width = 24)

p2_dim=plot_grid(ncol = 3, DimPlot(sce, reduction = "umap", group.by = "RNA_snn_res.0.8") + 
                   ggtitle("louvain_0.8"), DimPlot(sce, reduction = "umap", group.by = "RNA_snn_res.1") + 
                   ggtitle("louvain_1"), DimPlot(sce, reduction = "umap", group.by = "RNA_snn_res.3") + 
                   ggtitle("RNA_snn_res.3"))
p2_dim
ggsave(plot=p2_dim, filename="Neu_Dimplot_diff_resolution_high.pdf",width = 24)
table(sce@active.ident) 
p1_tree=clustree(sce@meta.data, prefix = "RNA_snn_res.")
p1_tree
ggsave(plot=p1_tree, filename="Neu_tree_diff_resolution.pdf",width = 12, height= 10)

saveRDS(sce, file = "Neu_cg_sce.rds")

################################################################################
library(Seurat)
library(ggplot2)
library(cowplot)
library(data.table)
library(harmony)
library(dplyr)
library(tidyr)
library(scop)
library(DT)
library(COSG)
library(scRNAtoolVis)
library(tidyverse)
library(readr)
library(plyr)
library(ggpubr)
library(patchwork)
library(rstatix)
library(dplyr)
library(monocle)
library(org.Hs.eg.db)
library(ClusterGVis)
library(slingshot)
library(SingleCellExperiment)
library(qs)
library(RColorBrewer)
library(SeuratObject)
mycolor <- c("#A6CEE3", "#1F78B4", "#B2DF8A", "#33A02C", "#FB9A99", 
             "#E31A1C", "#FDBF6F", "#FF7F00", "#CAB2D6", "#4DBBD5FF", 
             "#E64B35FF", "#00A087FF", "#3C5488FF", "#F39B7FFF", "#8491B4FF", 
             "#91D1C2FF", "#DC0000FF", "#7E6148FF", "#BC3C29FF", "#0072B5FF", 
             "#E18727FF", "#D24B27", "#D51F26", "#272E6A", "#208A42", "#89288F", 
             "#F47D2B", "#FEE500", "#8A9FD1", "#C06CAB", "#E6C2DC", "#90D5E4", 
             "#89C75F", "#F37B7D", "#9983BD", "#3BBCA8", "#6E4B9E", "#0C727C", 
             "#7E1416", "#D8A767", "#3D3D3D")

scRNA=readRDS("Neu_cg_sce.rds")
colnames(scRNA@meta.data)
apply(scRNA@meta.data[,grep("RNA_snn",colnames(scRNA@meta.data))],2,table)
Idents(scRNA) <- "RNA_snn_res.0.1"
markers_res01 <- FindAllMarkers(scRNA,only.pos = TRUE, min.pct = 0.25,logfc.threshold = 0.25)
write.csv(markers_res01, file = "Neu_markers_res01.csv", row.names = FALSE)
Idents(scRNA) <- "RNA_snn_res.0.3"
markers_res03 <- FindAllMarkers(scRNA,only.pos = TRUE, min.pct = 0.25,logfc.threshold = 0.25)
write.csv(markers_res03, file = "Neu_markers_res03.csv", row.names = FALSE)
Idents(scRNA) <- "RNA_snn_res.0.5"
markers_res05 <- FindAllMarkers(scRNA,only.pos = TRUE, min.pct = 0.25,logfc.threshold = 0.25)
write.csv(markers_res05, file = "Neu_markers_res05.csv", row.names = FALSE)

Idents(scRNA) <- "subcluster"
markers_res <- FindAllMarkers(scRNA,only.pos = TRUE, min.pct = 0.25,logfc.threshold = 0.25)
write.csv(markers_res, file = "Neu_markers_res.csv", row.names = FALSE)

sel.clust="subcluster"
scRNA<-SetIdent(scRNA,value=sel.clust)
table(scRNA@active.ident)
scRNA <- RunUMAP(scRNA,dims = 1:50,n.neighbors = 20,min.dist = 0.1,reduction = 'pca')
plot <- DimPlot(scRNA,group.by = 'subcluster', pt.size = 0.5, label = F)
plot

p_umap <- DimPlot(scRNA, reduction = "umap", group.by = "subcluster", pt.size = 1.5, cols = mycolor) 
p_umap
ggsave("Neu_umap_celltype.pdf", plot = p_umap, width = 10, height = 8)


table(scRNA$subcluster)
table(scRNA$sample)
scRNA@meta.data <- scRNA@meta.data %>% dplyr::select(-cluster,-group) %>%
  dplyr::rename(cluster = `RNA_snn_res.0.5`, group   = sample) %>%
  dplyr::mutate(cluster = recode(as.character(cluster),
                                 "0" = "Neu_1", "1" = "Neu_2", "2" = "Neu_3",
                                 "3" = "Neu_4", "4" = "Neu_5", "5" = "Neu_6"))
table(scRNA$group)
table(scRNA$cluster)

metadata <- FetchData(scRNA, c("sample","subcluster"))

cell_counts <- metadata %>%  
  dplyr::count(sample, subcluster)
total_cells <- cell_counts %>%
  dplyr::group_by(sample) %>%
  dplyr::summarise(total = sum(n))
cell_counts <- cell_counts %>%  
  left_join(total_cells, by = "sample")
cell_counts <- cell_counts %>%
  mutate(percentage = n / total*100)
head(cell_counts)
cell_counts$sample <- factor(cell_counts$sample,levels = c("ICH_6h", "ICH_24h", "ICH_48h"))
ggplot(cell_counts,aes(sample,percentage,fill=`subcluster`))+  
  geom_bar(stat = "identity",position="fill",width = 0.8,size = 1,colour = "black")+   
  theme_classic() +  
  labs(x='Group',y = 'Percentage')+  
  scale_fill_manual(values = mycolor)+  
  theme(axis.ticks.length=unit(0.1,'cm'))+  
  theme(text = element_text(size=15,colour = "black"),        
        axis.text.x = element_text(angle=45, hjust=1,colour = "black"),        
        axis.text.y= element_text(colour = "black"))
ggsave(file='Neu_ratio1.pdf', dpi =300, height =8, width =5)

ggplot(cell_counts,aes(sample,percentage,fill=`subcluster`))+  
  geom_bar(stat = "identity",position="fill",width = 0.8,size = 1,colour = "black")+   
  theme_classic() +
  labs(x='Group',y = 'Percentage')+  
  scale_fill_manual(values = mycolor)+  
  theme(axis.ticks.length=unit(0.1,'cm'))+  
  theme(text = element_text(size=15,colour = "black"),        
        axis.text.x = element_text(angle=45, hjust=1,colour = "black"),        
        axis.text.y= element_text(colour = "black")) +coord_flip()
ggsave(file='Neu_ratio2.pdf', dpi =300, height =4, width =10)

g.colSet = list(sample = c("ICH_6h" = mycolor[3], "ICH_24h" = mycolor[7], "ICH_48h" = mycolor[8]))
p.list.perMcls <- lapply(sort(unique(cell_counts$subcluster)), function(mcls) {
  text.size  <- 10
  text.angle <- 45
  text.hjust <- 1
  legend.position <- "none"
  p <- ggplot(dplyr::filter(cell_counts, subcluster == mcls),
              aes(x = sample, y = percentage, fill = sample)) +
    geom_col(width = 0.7,color = "black",linewidth = 0.5) +
    scale_fill_manual(values = g.colSet$sample) +
    labs(title = mcls,x = "",y = "Percentage") +
    coord_cartesian(clip = "off") +
    theme_classic() +
    theme( plot.title = element_text(size = text.size + 2, color = "black", hjust = 0.5),
           axis.ticks = element_line(color = "black"),
           axis.title = element_text(size = text.size, color = "black"),
           axis.text = element_text(size = text.size, color = "black"),
           axis.text.x = element_text(angle = text.angle, hjust = text.hjust),
           legend.position = legend.position)
  return(p)})
p.prop = wrap_plots(p.list.perMcls, ncol = 3)
p.prop
ggsave(p.prop,filename = "Neu_ratio.pdf",width =6,height =6)

############################################
FeaturePlot(scRNA,features = "CD55",reduction = "umap",cols = c("#2C7BB6", "#FFFFBF", "#D7191C"))

cd55_data <- FetchData(scRNA, vars = c("CD55", "subcluster"))
cd55_data %>%dplyr::group_by(subcluster) %>%
  dplyr::summarise(mean_exp = mean(CD55), n = n(), .groups = 'drop') %>%
  dplyr::filter(subcluster == "Neu_1") %>%pull(mean_exp) -> baseline_mean

stats_table <- combn(c("Neu_2", "Neu_3", "Neu_4", "Neu_5"), 1, simplify = FALSE) %>%
  lapply(function(x) {
    group1 <- cd55_data$CD55[cd55_data$subcluster == "Neu_1"]
    group2 <- cd55_data$CD55[cd55_data$subcluster == x]
    tt <- t.test(group1, group2)
    data.frame(Comparison = paste("Neu_1 vs", x),Mean_Neu_1 = mean(group1),
               SD_Neu_1 = sd(group1),n_Neu_1 = length(group1),
               Mean_Other = mean(group2),SD_Other = sd(group2),
               n_Other = length(group2),p_value = tt$p.value)}) %>%
  bind_rows()
print(stats_table)
write.csv(stats_table, "CD55_stats.csv", row.names = FALSE)

############################################
#library(reticulate)
#use_python("C:/Users/13990/miniconda3/python.exe", required = TRUE)
#py_config()
#import("numpy")
#import("sklearn")
#import("scipy")
#import("annoy")
#import("scanoramaCT")
#library(CytoTRACE)
library(CytoTRACE2)

scRNA=readRDS("Neu_cg_sce.rds")
str(scRNA,max.level = 1)
sce <- as.matrix(scRNA@assays$RNA@counts)
head(scRNA$subcluster)
table(scRNA$subcluster)
cytotrace2_result <- cytotrace2(sce, species = "human", ncores = 30)
# cytotrace2_result=readRDS("Neu_CytoTRACE.rds")
annotation <- data.frame(Phenotype_CT2 = as.character(scRNA$subcluster))
rownames(annotation) <- colnames(sce)
plots <- plotData(cytotrace2_result = cytotrace2_result,
                  annotation = annotation,
                  expression_data = sce)
plots$CytoTRACE2_UMAP
plots$CytoTRACE2_Potency_UMAP
plots$CytoTRACE2_Relative_UMAP
ggsave("Neu_CytoTRACE2_Relative_UMAP.pdf", width =9, height =7, dpi =300)
plots$Phenotype_UMAP
ggsave("Neu_Phenotype_UMAP.pdf", width =9, height =7, dpi =300)
plots$CytoTRACE2_Boxplot_byPheno
ggsave("Neu_CytoTRACE2_Boxplot_byPheno.pdf", width =9, height =7, dpi =300)
saveRDS(cytotrace2_result, file = "Neu_CytoTRACE.rds")

scRNA@meta.data$CytoTRACE<-cytotrace2_result$CytoTRACE2_Score
saveRDS(scRNA, file = "Neu_cg_sce.rds")

############################################
library(Seurat)
library(monocle)
library(clusterProfiler)
library(org.Hs.eg.db)
library(ClusterGVis)

scRNA=readRDS("Neu_cg_sce.rds")
sce <- as.matrix(scRNA@assays$RNA$counts)
row.names(sce)<-row.names(scRNA)
colnames(sce)<-colnames(scRNA)

pd <- new('AnnotatedDataFrame', data = scRNA@meta.data)
fData <- data.frame(gene_short_name = row.names(sce), row.names = row.names(sce))
fd <- new('AnnotatedDataFrame', data = fData)
mycds <- newCellDataSet(sce,phenoData = pd,featureData = fd,
                        expressionFamily = negbinomial.size())
mycds <- estimateSizeFactors(mycds)
mycds <- estimateDispersions(mycds, cores=8, relative_expr = TRUE)
mycds <- detectGenes(mycds, min_expr = 1)
expressed_genes <- row.names(subset(fData(mycds), num_cells_expressed >= 5))

disp_table <- dispersionTable(mycds)
disp.genes <- subset(disp_table, mean_expression >= 0.1 & dispersion_empirical >= 1 * dispersion_fit)$gene_id
mycds <- setOrderingFilter(mycds, disp.genes)
mycds <- reduceDimension(mycds, max_components = 2, method = 'DDRTree')

mycds <- orderCells(mycds)
table(pData(mycds)$State)
aggregate(CytoTRACE ~ State, pData(mycds), mean)

mycds <- orderCells(mycds, root_state = 1)
plot_cell_trajectory(mycds, color_by = "CytoTRACE")+scale_color_gradientn(
  colors = c("#2C7BB6", "#FFFFBF", "#D7191C"))
ggsave("Neu_CytoTRACE_UMAP.pdf", width =9, height =7, dpi =300)
plot_cell_trajectory(mycds, color_by = "Pseudotime")+scale_color_gradientn(
  colors = c("#2C7BB6", "#FFFFBF", "#D7191C"))
ggsave("Neu_Pseudotime_UMAP.pdf", width =9, height =7, dpi =300)
plot_cell_trajectory(mycds, color_by = "State")+scale_color_manual(values = mycolor)
ggsave("Neu_State_UMAP.pdf", width =9, height =7, dpi =300)
plot_cell_trajectory(mycds, color_by = "subcluster")+scale_color_manual(values = mycolor)
ggsave("Neu_subcluster_UMAP.pdf", width =9, height =7, dpi =300)
plot_cell_trajectory(mycds, color_by = "sample")+scale_color_manual(values = mycolor)
ggsave("Neu_sample_UMAP.pdf", width =9, height =7, dpi =300)
saveRDS(mycds, file = "Neu_monocle.rds")

pt    <- pData(mycds)$Pseudotime
state <- pData(mycds)$State
names(pt)    <- rownames(pData(mycds))
names(state) <- rownames(pData(mycds))
idx <- match(colnames(scRNA), names(pt))
scRNA$Pseudotime <- pt[idx]
scRNA$State      <- state[idx]
scRNA$Pseudotime <- as.numeric(scRNA$Pseudotime)
scRNA$State      <- as.factor(scRNA$State)
head(scRNA@meta.data[, c("Pseudotime", "State")])
scRNA@meta.data$subcluster <- paste0("Neu_", scRNA@meta.data$State)
saveRDS(scRNA, file = "Neu_cg_sce.rds")

############################################
library(slingshot)
library(SingleCellExperiment)
library(qs)
library(tidyverse)
library(RColorBrewer)
library(SeuratObject)
library(DelayedMatrixStats)
library(grDevices)

scRNA=readRDS("Neu_cg_sce.rds")
scRNA <- RunUMAP(scRNA,dims = 1:50,n.neighbors = 20,min.dist = 0.1,reduction = 'pca')
plot <- DimPlot(scRNA,group.by = 'subcluster', pt.size = 0.5, label = F)
plot
Idents(scRNA)=scRNA$subcluster
diff.wilcox = FindAllMarkers(scRNA, only.pos = TRUE, min.pct = 0.1,
                             thresh.use = 0.1)
all.markers = diff.wilcox %>%dplyr::select(gene, everything()) %>% subset(p_val<0.05)
diff.genes <- subset(all.markers,p_val_adj<0.001)$gene
scRNA <- as.SingleCellExperiment(scRNA, assay ="RNA")
sce_slingshot <- slingshot(scRNA,
                           reducedDim ='UMAP',
                           start.clus ='Neu_1',
                           clusterLabels = scRNA$subcluster)
SlingshotDataSet(sce_slingshot)
colors <- colorRampPalette(brewer.pal(11,'Spectral')[-6])(100)
plotcol <- colors[cut(sce_slingshot$slingPseudotime_1, breaks=100)]
plot(reducedDims(sce_slingshot)$UMAP, col = plotcol, pch=16, asp = 1)
lines(SlingshotDataSet(sce_slingshot), lwd=2, col='black')
saveRDS(sce_slingshot, file = "Neu_monocle.rds")

############################################
library(Seurat)
library(dplyr)
library(ggplot2)
library(clusterProfiler)
library(org.Hs.eg.db)
library(stringr)
library(tibble)
library(pheatmap)
library(forcats)
library(readr)
library(RColorBrewer)
library(tidyverse)
library(gground)
library(ggprism)
library(tidyverse)

Neu_cluster_marker_genes <- read.csv("Neu_markers_res.csv")
head(Neu_cluster_marker_genes)
Neu_filtered <- Neu_cluster_marker_genes %>%
  filter(abs(avg_log2FC) > 0.25, p_val_adj < 0.05)
write.csv(Neu_filtered, file = "Neu_marker_res_filtered.csv", row.names = FALSE)

Neu_filtered <- read.csv("Neu_marker_res_filtered.csv")
head(Neu_filtered)
Neu_split <- split(Neu_filtered, Neu_filtered$cluster)
for (g in names(Neu_split)) {
  filename <- paste0("Neu_cluster_", g, ".csv")
  write.csv(Neu_split[[g]], file = filename, row.names = FALSE)}
get_top5_genes <- function(split_data) {
  top_genes <- do.call(rbind, lapply(split_data, function(df) {
    df <- df[order(-df$avg_log2FC), ]
    head(df, 5)}))
  return(top_genes)}

Neu_top <- get_top5_genes(Neu_split)
Neu_genes <- unique(Neu_top$gene)
make_matrix <- function(data_split, selected_genes) {
  group_ids <- names(data_split)
  mat <- sapply(group_ids, function(g) {
    df <- data_split[[g]]
    gene_vals <- setNames(df$avg_log2FC, df$gene)
    sapply(selected_genes, function(gene) gene_vals[gene])})
  rownames(mat) <- selected_genes
  return(t(mat))}

Neu_matrix <- make_matrix(Neu_split, Neu_genes)
Neu_matrix[is.na(Neu_matrix)] <- 0
pheatmap(Neu_matrix, main = "Neu Top Genes", cluster_rows = TRUE, cluster_cols = TRUE, na_col = "grey")
ggsave("Neu_Top_Genes_heatmap.pdf", width = 12, height = 4)

convert_to_entrez <- function(gene_list) {
  bitr(gene_list,fromType = "SYMBOL",
       toType = "ENTREZID",OrgDb = org.Hs.eg.db)}

run_full_enrichment <- function(gene_symbols, prefix) {
  entrez_df <- convert_to_entrez(gene_symbols)
  entrez_ids <- entrez_df$ENTREZID
  gene_map <- entrez_df %>% distinct(ENTREZID, SYMBOL)
  if (length(entrez_ids) < 10) {
    message("Skip ", prefix, ": too few valid Entrez IDs.")
    return(NULL)}
  try({
    go_bp <- enrichGO(gene = entrez_ids, OrgDb = org.Hs.eg.db, ont = "BP", readable = TRUE)
    go_cc <- enrichGO(gene = entrez_ids, OrgDb = org.Hs.eg.db, ont = "CC", readable = TRUE)
    go_mf <- enrichGO(gene = entrez_ids, OrgDb = org.Hs.eg.db, ont = "MF", readable = TRUE)
    go_df <- bind_rows(
      mutate(as.data.frame(go_bp), Ontology = "BP"),
      mutate(as.data.frame(go_cc), Ontology = "CC"),
      mutate(as.data.frame(go_mf), Ontology = "MF"))
    write.csv(go_df, paste0(prefix, "_GO_combined.csv"), row.names = FALSE)
  }, silent = TRUE)
  try({
    kegg <- enrichKEGG(gene = entrez_ids, organism = 'hsa')
    if (!is.null(kegg)) {
      kegg_df <- as.data.frame(kegg)
      kegg_df$SYMBOL_GENE <- sapply(kegg_df$geneID, function(x) {
        ids <- unlist(strsplit(x, "/"))
        syms <- gene_map$SYMBOL[match(ids, gene_map$ENTREZID)]
        paste(syms, collapse = "/")
      })
      write.csv(kegg_df, paste0(prefix, "_KEGG.csv"), row.names = FALSE)}
  }, silent = TRUE)}

for (g in names(Neu_split)) {
  genes <- Neu_split[[g]]$gene
  prefix <- paste0("Neu_", g)
  run_full_enrichment(genes, prefix)
}

logFC_cutoff <- 0.585 
p_cutoff     <- 0.05
convert_gene <- function(genes) {
  bitr(genes,fromType = "SYMBOL",toType = "ENTREZID",OrgDb = org.Hs.eg.db) %>% 
    distinct(ENTREZID)}
run_GO <- function(entrez, prefix) {
  ego <- enrichGO(gene = entrez$ENTREZID,OrgDb = org.Hs.eg.db,
                  ont = "BP",pAdjustMethod = "BH",pvalueCutoff = 0.05,readable = TRUE)
  if (is.null(ego) || nrow(ego@result) == 0) return(NULL)
  write.csv(ego@result,file = paste0("Neu_Enrichment/GO/", prefix, "_GO.csv"),
            row.names = FALSE)
  p <- dotplot(ego, showCategory = 15) + ggtitle(prefix)
  ggsave(paste0("Neu_Enrichment/GO/", prefix, "_GO_dotplot.pdf"),p, 
         width = 7, height = 6)
}
run_KEGG <- function(entrez, prefix) {
  ekegg <- enrichKEGG(gene = entrez$ENTREZID,organism = "hsa",pvalueCutoff = 0.05)
  if (is.null(ekegg) || nrow(ekegg@result) == 0) return(NULL)
  write.csv(ekegg@result,file = paste0("Neu_Enrichment/KEGG/", prefix, "_KEGG.csv"),
            row.names = FALSE)
  p <- dotplot(ekegg, showCategory = 15) +ggtitle(prefix)
  ggsave(paste0("Neu_Enrichment/KEGG/", prefix, "_KEGG_dotplot.pdf"),p, 
         width = 7, height = 6)
}

dir.create("Neu_Enrichment/GO", recursive = TRUE, showWarnings = FALSE)
dir.create("Neu_Enrichment/KEGG", recursive = TRUE, showWarnings = FALSE)
files <- list.files("C:/Users/13990/Desktop/fsdownload/Neu_enrichment", full.names = TRUE)
for (f in files) {message("Processing: ", basename(f))
  df <- data.table::fread(f)
  prefix <- tools::file_path_sans_ext(basename(f))
  
  entrez <- convert_gene(deg_sig$gene)
  if (nrow(entrez) < 10) {message("  Skip enrichment: <10 Entrez IDs")
    next}
  run_GO(entrez, prefix)
  run_KEGG(entrez, prefix)
}

kegg <- read.csv("Neu_Neu_1_KEGG.csv")
ego <- read.csv("Neu_Neu_1_GO_combined.csv")

ego_use <- ego %>%
  filter(p.adjust < 0.05) %>% 
  group_by(Ontology) %>%      
  arrange(desc(FoldEnrichment), p.adjust) %>% 
  slice_head(n = 5) %>%   
  ungroup()

kegg_use <- kegg %>%
  filter(p.adjust < 0.05) %>%                  
  arrange(desc(FoldEnrichment), p.adjust) %>%  
  slice_head(n = 5) %>%                        
  mutate(Ontology = "kegg")

use_pathway <- bind_rows(ego_use, kegg_use) %>%
  mutate(
    Ontology = factor(
      Ontology,
      levels = rev(c("BP", "CC", "MF", "kegg"))
    )
  ) %>%
  arrange(Ontology, desc(FoldEnrichment)) %>%
  mutate(
    Description = factor(Description, levels = Description)
  ) %>%
  tibble::rowid_to_column("index")


width <- 1
xaxis_max <- max(use_pathway$Count) + 1
rect.data <- group_by(use_pathway, Ontology) %>%
  reframe(n = n()) %>%
  ungroup() %>%
  mutate(
    xmin = -3 * width,
    xmax = -2 * width,
    ymax = cumsum(n),
    ymin = lag(ymax, default = 0) + 0.6,
    ymax = ymax + 0.4)

pal <- c('#7bc4e2', '#acd372', '#fbb05b','#ed6ca4')
pdf('pathway_gene.pdf', width = 15, height = 12)
use_pathway %>%
  ggplot(aes(Count, y = index, fill = Ontology)) +
  geom_round_col(
    aes(y = Description), width = 0.6, alpha = 0.8) +
  geom_text(
    aes(x = 0.05, label = Description),
    hjust = 0, size = 5) +
  geom_text(
    aes(x = 0.1, label = geneID, colour = Ontology), 
    hjust = 0, vjust = 2.6, size = 3.5, fontface = 'italic', 
    show.legend = FALSE) +
  geom_point(
    aes(x = -width, size = Count),
    shape = 21) +
  geom_text(
    aes(x = -width, label = Count)) +
  scale_size_continuous(name = 'Count', range = c(5, 16)) +
  geom_round_rect(
    aes(xmin = xmin, xmax = xmax, ymin = ymin, ymax = ymax,
        fill = Ontology),
    data = rect.data,
    radius = unit(2, 'mm'),
    inherit.aes = FALSE) +
  geom_text(
    aes(x = (xmin + xmax) / 2, y = (ymin + ymax) / 2, label = Ontology),
    data = rect.data,
    inherit.aes = FALSE) +
  geom_segment(
    aes(x = 0, y = 0, xend = xaxis_max, yend = 0),
    data = data.frame(xaxis_max = xaxis_max),
    linewidth = 1.5,
    inherit.aes = FALSE) +
  labs(y = NULL) +
  scale_fill_manual(name = 'Category', values = pal) +
  scale_colour_manual(values = pal) +
  scale_x_continuous(
    breaks = seq(0, xaxis_max, 10), 
    expand = expansion(c(0, 0))) +
  theme_prism() +
  theme(
    axis.text.y = element_blank(),
    axis.line = element_blank(),
    axis.ticks.y = element_blank(),
    legend.title = element_text())
dev.off()


############################################
library(Seurat)
library(ggsignif)
library(ggpubr)
library(cowplot)
library(dplyr)
library(NMF)
library(ggalluvial)
library(CellChat)
library(pheatmap)
library(patchwork)
library(future)
library(ggplot2)
library(tidyverse)
library(ComplexHeatmap)
library(presto)

Neu_cg_sce = readRDS("Neu_cg_sce.rds")
sce = readRDS("sce_celltype_cells.rds")

length(intersect(colnames(Neu_cg_sce), colnames(sce)))
sce$celltype[sce$celltype == "Neutrophil"] <- NA
table(sce$celltype, useNA = "ifany")
common.cells <- intersect(colnames(sce), colnames(Neu_cg_sce))
sce$celltype[common.cells] <- Neu_cg_sce$subcluster[common.cells]
table(sce$celltype)
saveRDS(sce, file = "combined_cg_sce.rds")

dim(sce)
table(sce$celltype)
table(sce$sample)

for (sample in unique(sce$sample)) {  
  pbmc_subset <- sce[,sce$sample == sample]  
  pbmc_cellchat <- createCellChat(pbmc_subset[["RNA"]]$data)  
  pbmc_meta <- data.frame(celltype = pbmc_subset$celltype, 
                          row.names =  Cells(pbmc_subset))    
  pbmc_cellchat <- addMeta(pbmc_cellchat, meta = pbmc_meta, meta.name = "celltype")  
  pbmc_cellchat <- setIdent(pbmc_cellchat, ident.use = "celltype")
  groupSize <- as.numeric(table(pbmc_cellchat@idents)) 
  CellChatDB <- CellChatDB.human  
  str(CellChatDB)  
  colnames(CellChatDB$interaction)  
  CellChatDB$interaction[1:4,1:4]  
  head(CellChatDB$complex)  
  head(CellChatDB$cofactor)  
  head(CellChatDB$geneInfo)
  showDatabaseCategory(CellChatDB)
  CellChatDB.use <- CellChatDB  
  pbmc_cellchat@DB <- CellChatDB.use 
  pbmc_cellchat<- subsetData(pbmc_cellchat) 
  pbmc_cellchat <- identifyOverExpressedGenes(pbmc_cellchat)   
  pbmc_cellchat <- identifyOverExpressedInteractions(pbmc_cellchat) 
  pbmc_cellchat <- smoothData(pbmc_cellchat, adj = PPI.human)   
  options(future.globals.maxSize = 3000000000)   
  pbmc_cellchat <- computeCommunProb(pbmc_cellchat) 
  pbmc_cellchat <- filterCommunication(pbmc_cellchat, min.cells =10) 
  pbmc_cellchat <- computeCommunProbPathway(pbmc_cellchat)  
  pbmc_cellchat <- aggregateNet(pbmc_cellchat)    
  pbmc_cellchat <- netAnalysis_computeCentrality(pbmc_cellchat, slot.name = "netP")   
  saveRDS(pbmc_cellchat,paste0(sample,'_Cellchat.rds'))
}

cellchat_6h <- readRDS("C:/Users/13990/Desktop/fsdownload/ICH_6h_Cellchat.rds")
cellchat_24h <- readRDS("C:/Users/13990/Desktop/fsdownload/ICH_24h_Cellchat.rds")
cellchat_48h <- readRDS("C:/Users/13990/Desktop/fsdownload/ICH_48h_Cellchat.rds")

object.list <- list("G1" = cellchat_6h, "G2" = cellchat_24h, "G3" = cellchat_48h)
cellchat <- mergeCellChat(object.list, add.names = names(object.list))
cellchat@idents <- factor(rep(c("G1", "G2", "G3"),
                              times = sapply(object.list, function(x) ncol(x@data))))
print(levels(cellchat@idents))
print(names(cellchat@idents))
cellchat

G1 <- aggregateNet(cellchat_6h)
G2 <- aggregateNet(cellchat_24h)
G3 <- aggregateNet(cellchat_48h)

par(mfrow = c(1,2), xpd=TRUE)
groupSize <- as.numeric(table(G1@idents))
netVisual_circle(G1@net$count, vertex.weight = groupSize,
                 weight.scale = T, label.edge= F, 
                 title.name = "Number of interactions G1")
netVisual_circle(G1@net$weight, vertex.weight = groupSize,
                 weight.scale = T, label.edge= F, 
                 title.name = "Interaction weights/strength G1")
ggsave("G1_circle.pdf", height = 6,width = 9)

par(mfrow = c(1,2), xpd=TRUE)
groupSize <- as.numeric(table(G2@idents))
netVisual_circle(G2@net$count, vertex.weight = groupSize,
                 weight.scale = T, label.edge= F, 
                 title.name = "Number of interactions G2")
netVisual_circle(G2@net$weight, vertex.weight = groupSize,
                 weight.scale = T, label.edge= F, 
                 title.name = "Interaction weights/strength G2")

par(mfrow = c(1,2), xpd=TRUE)
groupSize <- as.numeric(table(G3@idents))
netVisual_circle(G3@net$count, vertex.weight = groupSize,
                 weight.scale = T, label.edge= F, 
                 title.name = "Number of interactions G3")
netVisual_circle(G3@net$weight, vertex.weight = groupSize,
                 weight.scale = T, label.edge= F, 
                 title.name = "Interaction weights/strength G3")

gg1 <- netVisual_heatmap(cellchat)
gg2 <- netVisual_heatmap(cellchat, measure = "weight")
gg1 + gg2

lr_G1 <- subsetCommunication(G1)
lr_G2 <- subsetCommunication(G2)
lr_G3 <- subsetCommunication(G3)

write.csv(lr_G1, "G1_LR_communication.csv", row.names = FALSE)
write.csv(lr_G2, "G2_LR_communication.csv", row.names = FALSE)
write.csv(lr_G3, "G3_LR_communication.csv", row.names = FALSE)

pathway_G1 <- subsetCommunication(G1, slot.name = "netP")
pathway_G2 <- subsetCommunication(G2, slot.name = "netP")
pathway_G3 <- subsetCommunication(G3, slot.name = "netP")

write.csv(pathway_G1, "G1_pathway_communication.csv", row.names = FALSE)
write.csv(pathway_G2, "G2_pathway_communication.csv", row.names = FALSE)
write.csv(pathway_G3, "G3_pathway_communication.csv", row.names = FALSE)

i = 1
pathway.union <- union(object.list[[i]]@netP$pathways, object.list[[i+1]]@netP$pathways)
ht1 = netAnalysis_signalingRole_heatmap(object.list[[i]], pattern = "all", 
                                        signaling = pathway.union, title = names(object.list)[i], 
                                        width = 8, height = 35, color.heatmap = "OrRd")
ht2 = netAnalysis_signalingRole_heatmap(object.list[[i]], pattern = "all", 
                                        signaling = pathway.union, title = names(object.list)[i], 
                                        width = 8, height = 35, color.heatmap = "OrRd")
ht3 = netAnalysis_signalingRole_heatmap(object.list[[i+1]], pattern = "all", 
                                        signaling = pathway.union, title = names(object.list)[i+2], 
                                        width = 8, height = 35, color.heatmap = "OrRd")
draw(ht1 + ht2 +ht3, ht_gap = unit(0.5, "cm"))

levels(G1@idents)
netVisual_bubble(G1, sources.use = c(5,6,7,8,9), targets.use = c(1,2,3,4,10,11,12), angle.x = 45)
gg1 <- netVisual_bubble(G1, sources.use = c(5,6,7,8,9), targets.use = c(1,2,3,4,10,11,12),  max.dataset = 2, 
                        angle.x = 45, remove.isolate = T)
gg1
ggsave("inter_G1.pdf",gg1,height = 13,width = 8)
netVisual_bubble(G2, sources.use = c(5,6,7,8,9), targets.use = c(1,2,3,4,10,11,12), angle.x = 45)
gg2 <- netVisual_bubble(G2, sources.use = c(5,6,7,8,9), targets.use = c(1,2,3,4,10,11,12),   max.dataset = 2, 
                        angle.x = 45, remove.isolate = T)
gg2
ggsave("inter_G2.pdf",gg2,height = 8,width = 8)
netVisual_bubble(G3, sources.use = c(5,6,7,8,9), targets.use = c(1,2,3,4,10,11,12), angle.x = 45)
gg3 <- netVisual_bubble(G3, sources.use = c(5,6,7,8,9), targets.use = c(1,2,3,4,10,11,12),   max.dataset = 2, 
                        angle.x = 45, remove.isolate = T)
gg3
ggsave("inter_G3.pdf",gg3,height = 14.5,width = 8)

G1@netP$pathways
levels(G1@idents) 
pathways.show <- "ADGRE"
netVisual_heatmap(G1, signaling = pathways.show, color.heatmap = "Reds")
netVisual_bubble(G1,signaling = c("ADGRE"),remove.isolate = FALSE)
plotGeneExpression(G1, signaling = "ADGRE",enriched.only = TRUE,type = "violin",color.use = mycolor)

G2@netP$pathways
levels(G2@idents) 
pathways.show <- "ADGRE"
netVisual_heatmap(G2, signaling = pathways.show, color.heatmap = "Reds")
netVisual_bubble(G2,signaling = c("ADGRE"),remove.isolate = FALSE)
plotGeneExpression(G2, signaling = "ADGRE",enriched.only = TRUE,type = "violin",color.use = mycolor)

G3@netP$pathways
levels(G3@idents) 
pathways.show <- "ADGRE"
netVisual_heatmap(G3, signaling = pathways.show, color.heatmap = "Reds")
netVisual_bubble(G3,signaling = c("ADGRE"),remove.isolate = FALSE)
plotGeneExpression(G3, signaling = "ADGRE",enriched.only = TRUE,type = "violin",color.use = mycolor)

############################################
library(scMetabolism)
library(ggplot2)
library(rsvd)
library(stringr)
library(reshape2)
library(scales)
library(scater)
library(dplyr)
library(ggrepel)
library(RColorBrewer)
library(ggsci)
library(fgsea)
library(AUCell)
library(Seurat)

Neu_cg_sce = readRDS("Neu_cg_sce.rds")

countexp.Seurat<-sc.metabolism.Seurat(obj = Neu_cg_sce,   
                                      method = "VISION",   
                                      imputation = F,  
                                      metabolism.type = "KEGG")
metabolism.matrix <- countexp.Seurat@assays$METABOLISM$score
metabolism.matrix
input.pathway<- rownames(countexp.Seurat@assays$METABOLISM$score)
input.pathway
p1 = DotPlot.metabolism(obj = countexp.Seurat,                    
                        pathway = input.pathway,                    
                        phenotype = "subcluster",                    
                        norm = "y")
ggsave("scMetabolism_dotplot.pdf",p1,width = 7,height = 20)

countexp.Seurat1<-sc.metabolism.Seurat(obj = Neu_cg_sce,   
                                       method = "AUCell",  
                                       imputation = F,  
                                       metabolism.type = "KEGG")
metabolism.matrix1 <- countexp.Seurat1@assays$METABOLISM$score
metabolism.matrix1
input.pathway1<- rownames(countexp.Seurat1@assays$METABOLISM$score)
input.pathway1
p2 = DotPlot.metabolism(obj = countexp.Seurat1,                    
                        pathway = input.pathway1,                    
                        phenotype = "subcluster",                    
                        norm = "y")
ggsave("scMetabolism_dotplot1.pdf",p2,width = 7,height = 30)

input.pathway <- c("Terpenoid backbone biosynthesis",
                   "Starch and sucrose metabolism",
                   "Nicotinate and nicotinamide metabolism",
                   "Inositol phosphate metabolism",
                   "Glycosaminoglycan biosynthesis - chondroitin sulfate / dermatan sulfate",
                   "Fatty acid elongation",
                   "Biosynthesis of unsaturated fatty acids")
p3 = BoxPlot.metabolism(obj = countexp.Seurat,                                                                                 
                        pathway = input.pathway,                                                                                 
                        phenotype = "subcluster", ncol = 1)
ggsave("scMetabolism_boxplot.pdf",p3,width = 7,height = 30)

p4 = DotPlot.metabolism(obj = countexp.Seurat,                    
                        pathway = input.pathway,                    
                        phenotype = "subcluster",                    
                        norm = "y")
ggsave("scMetabolism_dotplot2.pdf",p4,width = 7,height = 5)

sce_Metal_exp = countexp.Seurat
sce_Metal_exp$celltype = sce_Metal_exp$subcluster
mscore_data = data.frame(t(sce_Metal_exp@assays[["METABOLISM"]][["score"]]),
                         sce_Metal_exp$celltype)
avg_sM=aggregate(mscore_data[,1:ncol(mscore_data)-1],
                 list(mscore_data$sce_Metal_exp.celltype),mean)
rownames(avg_sM) = avg_sM$Group.1
avg_sM=data.frame(t(avg_sM[,-1]))
avg_sM$KEGG = rownames(sce_Metal_exp@assays[["METABOLISM"]][["score"]])
rownames(avg_sM)=avg_sM$KEGG
c_k_l = c()
for(c in c(1:ncol(avg_sM))){  
  c_k=avg_sM[order(avg_sM[,c]),]$KEGG
  c_k_l=c(c_k_l,c_k)
}
c_k_l= unique(c_k_l)
c_k_d <- avg_sM[input.pathway, , drop = FALSE]
rownames(c_k_d) = c_k_d$KEGG
pheatmap::pheatmap(c_k_d[,-ncol(c_k_d)],show_colnames = T,scale='row')
